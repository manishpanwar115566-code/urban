# Urban by Grace — Cloudflare deployment

This is a Vite + React + TypeScript project. Do not use Cloudflare's direct **Upload and deploy** flow with the source ZIP. It contains `.tsx` source files and needs a build step first.

## Recommended: Cloudflare Pages via GitHub

1. Create a GitHub repository and upload the contents of this project (the files inside the ZIP, not the ZIP itself).
2. In Cloudflare Dashboard, open **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
3. Select the repository.
4. Set the build configuration:
   - Framework preset: **Vite** (or **None**)
   - Build command: `npm run build`
   - Build output directory: `dist`
   - Root directory: `/`
5. Save and deploy. Cloudflare will install dependencies, run the Vite build, and publish `dist`.

## Alternative: deploy from a computer with Wrangler

Prerequisites: Node.js 20.19+ (or 22.12+) and an internet connection.

```bash
npm install
npm run build
npx wrangler login
npx wrangler deploy
```

The `wrangler.jsonc` file publishes the generated `dist` directory as static assets and enables SPA fallback routing.

## Important

- A successful deployment creates a `*.workers.dev` URL in your Cloudflare account.
- This project currently uses browser local storage for cart and wishlist state. A production store still needs a real backend/database, customer authentication, order processing, and a payment gateway before accepting real orders.
- Never upload `.env` files or API secrets to a public GitHub repository.
