import React from 'react';
import {
  ArrowRight,
  Truck,
  RotateCcw,
  ShieldCheck,
  Headphones,
} from 'lucide-react';
import { GENERATED_ASSETS } from '../data/catalog';
import { PageId } from '../types/store';

interface CollectionBannersProps {
  onNavigate: (page: PageId) => void;
}

export const CollectionBanners: React.FC<CollectionBannersProps> = ({
  onNavigate,
}) => {
  return (
    <section className="py-4 sm:py-6 bg-[#FAF5F0]">
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* 1. TWO PROMOTIONAL COLLECTION BANNERS SIDE BY SIDE */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          {/* Banner 1 – Ethnic Collection */}
          <div
            onClick={() => onNavigate('ethnic-wear')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onNavigate('ethnic-wear');
            }}
            className="group relative rounded-2xl overflow-hidden bg-[#EADBC9] border border-[#281A1D]/10 min-h-[290px] sm:min-h-[330px] flex items-center cursor-pointer shadow-xs hover:shadow-md transition-all"
          >
            <img
              src={GENERATED_ASSETS.bannerEthnicCream}
              alt="Elegant Ethnic Wear For Every Occasion"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-right transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#F4E9DC] via-[#F4E9DC]/85 to-transparent sm:w-4/5 pointer-events-none" />

            <div className="relative z-10 p-6 sm:p-9 lg:p-10 max-w-xs">
              <h2 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D] leading-[1.12]">
                <span className="block italic font-normal text-[#701C35]">
                  Elegant
                </span>
                <span className="block">Ethnic Wear</span>
              </h2>
              <p className="mt-2.5 text-sm text-[#5A4B4E] font-medium">
                For Every Occasion
              </p>
              <span className="mt-6 inline-flex items-center gap-2 bg-[#701C35] group-hover:bg-[#3D101D] text-white text-xs sm:text-sm font-medium px-5 py-2.5 rounded-full transition-colors">
                <span>Shop Ethnic</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </span>
            </div>
          </div>

          {/* Banner 2 – Western Collection */}
          <div
            onClick={() => onNavigate('western-wear')}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') onNavigate('western-wear');
            }}
            className="group relative rounded-2xl overflow-hidden bg-[#172B21] border border-[#281A1D]/10 min-h-[290px] sm:min-h-[330px] flex items-center cursor-pointer shadow-xs hover:shadow-md transition-all"
          >
            <img
              src={GENERATED_ASSETS.bannerWesternGreen}
              alt="Trendy Western Wear Casual to Classy Looks"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#13261C]/95 via-[#13261C]/75 to-transparent sm:w-4/5 pointer-events-none" />

            <div className="relative z-10 p-6 sm:p-9 lg:p-10 max-w-xs text-white">
              <h2 className="font-serif-display text-3xl sm:text-4xl font-semibold leading-[1.12]">
                <span className="block italic font-normal text-[#E8C5CA]">
                  Trendy
                </span>
                <span className="block">Western Wear</span>
              </h2>
              <p className="mt-2.5 text-sm text-white/85 font-medium">
                Casual to Classy Looks
              </p>
              <span className="mt-6 inline-flex items-center gap-2 bg-[#FAF5F0] group-hover:bg-[#E8C5CA] text-[#281A1D] text-xs sm:text-sm font-medium px-5 py-2.5 rounded-full transition-colors">
                <span>Shop Western</span>
                <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
              </span>
            </div>
          </div>
        </div>

        {/* 2. FOUR-COLUMN SHOPPING BENEFITS STRIP */}
        <div className="bg-[#F2E8DF]/80 border border-[#281A1D]/10 rounded-2xl py-5 px-4 sm:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-y-6 gap-x-4 lg:divide-x lg:divide-[#281A1D]/10">
            <div className="flex items-center justify-center gap-3.5 px-2">
              <div className="w-10 h-10 rounded-full bg-[#FAF5F0] border border-[#701C35]/20 flex items-center justify-center text-[#701C35] shrink-0">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#281A1D]">
                  Free Shipping
                </p>
                <p className="text-xs text-[#77706D]">Above ₹999</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3.5 px-2">
              <div className="w-10 h-10 rounded-full bg-[#FAF5F0] border border-[#701C35]/20 flex items-center justify-center text-[#701C35] shrink-0">
                <RotateCcw className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#281A1D]">
                  Easy Returns
                </p>
                <p className="text-xs text-[#77706D]">Within 7 Days</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3.5 px-2">
              <div className="w-10 h-10 rounded-full bg-[#FAF5F0] border border-[#701C35]/20 flex items-center justify-center text-[#701C35] shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#281A1D]">
                  Secure Payment
                </p>
                <p className="text-xs text-[#77706D]">100% Safe &amp; Secure</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3.5 px-2">
              <div className="w-10 h-10 rounded-full bg-[#FAF5F0] border border-[#701C35]/20 flex items-center justify-center text-[#701C35] shrink-0">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-semibold text-[#281A1D]">
                  Customer Support
                </p>
                <p className="text-xs text-[#77706D]">Always Here for You</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
