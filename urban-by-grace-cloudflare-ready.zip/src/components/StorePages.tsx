import React, { useState } from 'react';
import {
  Heart,
  SlidersHorizontal,
  User,
  Package,
  MapPin,
  Mail,
  Phone,
  CheckCircle2,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import {
  FilterOptions,
  OrderRecord,
  PageId,
  Product,
  SizeOption,
} from '../types/store';
import { filterAndSortProducts, formatINR } from '../utils/commerce';
import { ProductCard } from './ProductCard';
import { GENERATED_ASSETS } from '../data/catalog';

/* ============================================================================
   1. COLLECTION / CATEGORY LISTING VIEW
   ============================================================================ */
interface CatalogListingViewProps {
  pageId: PageId;
  products: Product[];
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickView?: (product: Product) => void;
}

const PAGE_HEADERS: Record<
  string,
  { kicker: string; title: string; subtitle: string }
> = {
  women: {
    kicker: "WOMEN'S LUXURY EDIT",
    title: "Women's Collection",
    subtitle:
      'Handcrafted Indian ethnic ensembles, breezy floral midis, and sharp western tailoring.',
  },
  men: {
    kicker: "MEN'S HERITAGE & RESORT",
    title: "Men's Collection",
    subtitle:
      'Refined silk-blend bandhgala kurtas and breathable Giza cotton-linen shirts.',
  },
  'new-arrivals': {
    kicker: 'NEW SEASON 2026',
    title: 'New Arrivals',
    subtitle:
      'Fresh off our Jaipur and Mumbai design studios — modern fashion with everyday grace.',
  },
  'ethnic-wear': {
    kicker: 'HERITAGE CRAFTSMANSHIP',
    title: 'Elegant Ethnic Wear',
    subtitle:
      'Intricate Zardozi, Lucknowi Chikankari, and Gota Patti ensembles for every festive occasion.',
  },
  'western-wear': {
    kicker: 'CONTEMPORARY SILHOUETTES',
    title: 'Trendy Western Wear',
    subtitle:
      'Casual to classy looks crafted in organic poplin, European linen, and structured crepe.',
  },
  dresses: {
    kicker: 'EFFORTLESS DAY-TO-EVENING',
    title: 'Dresses',
    subtitle:
      'Botanical print tiered midis and structured A-line silhouettes.',
  },
  'kurtas-suits': {
    kicker: 'FESTIVE & EVERYDAY GRACE',
    title: 'Kurtas & Suit Sets',
    subtitle:
      'Complete three-piece kurta sets paired with tailored trousers and organza dupattas.',
  },
  'tops-tees': {
    kicker: 'WARDROBE ESSENTIALS',
    title: 'Tops, Shirts & Tees',
    subtitle: 'Crisp Supima cotton shirts and elevated everyday separates.',
  },
  'coord-sets': {
    kicker: 'MATCHING SETS',
    title: 'Tailored Co-ord Sets',
    subtitle: 'Architectural waistcoat sets and breezy resort linen pairings.',
  },
  'bags-accessories': {
    kicker: 'FINISHING TOUCHES',
    title: 'Bags & Fine Accessories',
    subtitle:
      'Hand-embroidered Zardozi bridal potlis and 22K gold-plated Kundan jewellery.',
  },
  sale: {
    kicker: 'LIMITED TIME PATRON PRIVILEGE',
    title: 'The Season Sale — Up to 40% Off',
    subtitle:
      'Curated luxury styles at special privileges. Apply code GRACE10 for an extra 10% off.',
  },
};

export const CatalogListingView: React.FC<CatalogListingViewProps> = ({
  pageId,
  products,
  wishlistIds,
  onToggleWishlist,
  onQuickAddToCart,
  onSelectProduct,
  onQuickView,
}) => {
  const [selectedSize, setSelectedSize] = useState<SizeOption | 'ALL'>('ALL');
  const [priceRange, setPriceRange] =
    useState<FilterOptions['priceRange']>('all');
  const [sortBy, setSortBy] = useState<FilterOptions['sortBy']>('featured');

  const meta = PAGE_HEADERS[pageId] || {
    kicker: 'URBAN BY GRACE',
    title: 'Curated Collection',
    subtitle: 'Modern Fashion, Everyday Grace.',
  };

  const filtered = filterAndSortProducts(products, {
    pageId,
    selectedSize,
    priceRange,
    sortBy,
  });

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Editorial Banner Header */}
      <div className="bg-[#F2E8DF] border border-[#281A1D]/10 rounded-2xl p-6 sm:p-10 mb-8 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#701C35] mb-2">
          {meta.kicker}
        </p>
        <h1 className="font-serif-display text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#281A1D]">
          {meta.title}
        </h1>
        <p className="text-sm text-[#77706D] max-w-2xl mx-auto mt-2.5">
          {meta.subtitle}
        </p>
      </div>

      {/* Filter & Sort Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 mb-6 border-b border-[#281A1D]/10">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#281A1D]">
            <SlidersHorizontal className="w-4 h-4 text-[#701C35]" />
            <span>Size:</span>
          </div>
          {(['ALL', 'XS', 'S', 'M', 'L', 'XL', 'XXL'] as const).map((sz) => (
            <button
              key={sz}
              type="button"
              onClick={() => setSelectedSize(sz)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                selectedSize === sz
                  ? 'bg-[#701C35] text-white'
                  : 'bg-white border border-[#281A1D]/15 text-[#281A1D] hover:border-[#701C35]'
              }`}
            >
              {sz === 'ALL' ? 'All Sizes' : sz}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter by price range"
            value={priceRange}
            onChange={(e) => setPriceRange(e.target.value as any)}
            className="px-3.5 py-2 rounded-lg bg-white border border-[#281A1D]/15 text-xs font-medium text-[#281A1D] focus:outline-none focus:border-[#701C35]"
          >
            <option value="all">All Prices</option>
            <option value="under-1500">Under ₹1,500</option>
            <option value="1500-2500">₹1,500 – ₹2,500</option>
            <option value="above-2500">Above ₹2,500</option>
          </select>

          <select
            aria-label="Sort products by"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3.5 py-2 rounded-lg bg-white border border-[#281A1D]/15 text-xs font-medium text-[#281A1D] focus:outline-none focus:border-[#701C35]"
          >
            <option value="featured">Sort: Featured</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="discount">Highest Discount</option>
            <option value="rating">Customer Rating</option>
          </select>
        </div>
      </div>

      {/* Product Grid */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#281A1D]/10 p-12 text-center space-y-3">
          <p className="font-serif-display text-2xl text-[#281A1D]">
            No styles match these exact filters
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedSize('ALL');
              setPriceRange('all');
            }}
            className="px-5 py-2.5 rounded-full bg-[#701C35] text-white text-xs font-semibold cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filtered.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isWishlisted={wishlistIds.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
              onQuickAddToCart={onQuickAddToCart}
              onSelectProduct={onSelectProduct}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   2. WISHLIST PAGE VIEW
   ============================================================================ */
interface WishlistViewProps {
  products: Product[];
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onNavigate: (page: PageId) => void;
  onQuickView?: (product: Product) => void;
}

export const WishlistView: React.FC<WishlistViewProps> = ({
  products,
  wishlistIds,
  onToggleWishlist,
  onQuickAddToCart,
  onSelectProduct,
  onNavigate,
  onQuickView,
}) => {
  const wishlistedProducts = products.filter((p) =>
    wishlistIds.includes(p.id)
  );

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="mb-8">
        <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35]">
          SAVED FAVORITES
        </p>
        <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
          My Wishlist ({wishlistedProducts.length})
        </h1>
      </div>

      {wishlistedProducts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#281A1D]/10 p-12 text-center max-w-xl mx-auto space-y-4">
          <Heart className="w-12 h-12 text-[#701C35] mx-auto" />
          <h2 className="font-serif-display text-2xl text-[#281A1D]">
            Your Wishlist is Empty
          </h2>
          <p className="text-sm text-[#77706D]">
            Tap the heart icon on any style to save your favorite ethnic suits,
            dresses, and co-ords for later.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('new-arrivals')}
            className="inline-flex items-center gap-2 bg-[#701C35] hover:bg-[#3D101D] text-white text-sm font-medium px-6 py-3 rounded-full transition-colors cursor-pointer"
          >
            <span>Explore New Arrivals</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {wishlistedProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              isWishlisted={true}
              onToggleWishlist={onToggleWishlist}
              onQuickAddToCart={onQuickAddToCart}
              onSelectProduct={onSelectProduct}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   3. MY ACCOUNT PAGE VIEW
   ============================================================================ */
interface AccountViewProps {
  orders: OrderRecord[];
  onNavigate: (page: PageId) => void;
}

export const AccountView: React.FC<AccountViewProps> = ({
  orders,
  onNavigate,
}) => {
  const [userProfile, setUserProfile] = useState({
    isLoggedIn: true,
    name: 'Ananya Sharma',
    email: 'ananya.sharma@urbanbygrace.in',
    phone: '+91 98765 43210',
    city: 'Mumbai, Maharashtra',
  });
  const [loginEmail, setLoginEmail] = useState('');
  const [loginName, setLoginName] = useState('');

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail.trim()) return;
    setUserProfile({
      isLoggedIn: true,
      name: loginName.trim() || 'Grace Patron',
      email: loginEmail.trim(),
      phone: '+91 98765 43210',
      city: 'Mumbai, Maharashtra',
    });
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D] mb-8">
        My Account
      </h1>

      {!userProfile.isLoggedIn ? (
        <div className="max-w-md mx-auto bg-white rounded-2xl border border-[#281A1D]/10 p-6 sm:p-8 space-y-5">
          <h2 className="font-serif-display text-2xl font-semibold text-[#281A1D]">
            Sign In to Urban by Grace
          </h2>
          <form onSubmit={handleSignIn} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#281A1D] mb-1">
                Full Name
              </label>
              <input
                type="text"
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                placeholder="Ananya Sharma"
                required
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#281A1D] mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                placeholder="patron@example.com"
                required
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
              />
            </div>
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#701C35] text-white text-sm font-semibold cursor-pointer"
            >
              Sign In
            </button>
          </form>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Patron Profile Card */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-4">
              <div className="flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-full bg-[#701C35] text-white flex items-center justify-center font-serif-display text-xl">
                  {userProfile.name.charAt(0)}
                </div>
                <div>
                  <h2 className="text-base font-semibold text-[#281A1D]">
                    {userProfile.name}
                  </h2>
                  <p className="text-xs text-[#701C35] font-medium">
                    Urban by Grace Privé Member
                  </p>
                </div>
              </div>

              <div className="space-y-2 text-xs text-[#77706D] pt-2 border-t border-[#281A1D]/10">
                <p className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#701C35]" />
                  <span>{userProfile.email}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#701C35]" />
                  <span>{userProfile.phone}</span>
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#701C35]" />
                  <span>{userProfile.city}</span>
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  setUserProfile({ ...userProfile, isLoggedIn: false })
                }
                className="text-xs font-semibold text-[#701C35] hover:underline cursor-pointer"
              >
                Switch Account / Sign Out
              </button>
            </div>
          </div>

          {/* Right: Order History */}
          <div className="lg:col-span-8 space-y-4">
            <div className="p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-4">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-[#701C35]" />
                <h2 className="font-serif-display text-2xl font-semibold text-[#281A1D]">
                  Recent Orders ({orders.length})
                </h2>
              </div>

              {orders.length === 0 ? (
                <div className="py-8 text-center space-y-3">
                  <p className="text-sm text-[#77706D]">
                    You haven&apos;t placed an order in this session yet.
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigate('new-arrivals')}
                    className="px-5 py-2.5 rounded-full bg-[#701C35] text-white text-xs font-semibold cursor-pointer"
                  >
                    Browse New Arrivals
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {orders.map((ord) => (
                    <div
                      key={ord.orderId}
                      className="p-4 rounded-xl bg-[#FAF5F0] border border-[#281A1D]/10 space-y-2"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-sm font-bold text-[#281A1D]">
                          Order #{ord.orderId}
                        </span>
                        <span className="text-xs font-semibold text-[#701C35]">
                          {ord.status} · {ord.estimatedDelivery}
                        </span>
                      </div>
                      <p className="text-xs text-[#77706D]">
                        Placed on {ord.placedAt} · {ord.summary.itemCount} Items
                        · Total{' '}
                        <strong className="text-[#281A1D] tabular-nums">
                          {formatINR(ord.summary.payableAmount)}
                        </strong>
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   4. EDITORIAL BRAND & POLICY PAGES (About, Contact, Privacy, Shipping, Return)
   ============================================================================ */
interface EditorialPageViewProps {
  pageId: PageId;
  onNavigate: (page: PageId) => void;
}

export const EditorialPageView: React.FC<EditorialPageViewProps> = ({
  pageId,
  onNavigate,
}) => {
  const [contactSent, setContactSent] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  if (pageId === 'about') {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center bg-white p-6 sm:p-10 rounded-3xl border border-[#281A1D]/10">
          <div className="space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35]">
              OUR HERITAGE STORY
            </p>
            <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
              Style That Speaks. Grace That Lasts.
            </h1>
            <p className="text-sm text-[#77706D] leading-relaxed">
              Founded with a vision to bridge timeless Indian textile artistry
              and contemporary western silhouettes,{' '}
              <strong className="text-[#281A1D]">Urban by Grace</strong> works
              directly with master karigars in Jaipur, Lucknow, and Maheshwar
              alongside modern pattern-makers in Mumbai.
            </p>
            <p className="text-sm text-[#77706D] leading-relaxed">
              Every garment is finished with breathable mulmul linings,
              natural shell buttons, and enduring fabrics designed for the
              modern Indian wardrobe.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('new-arrivals')}
              className="inline-flex items-center gap-2 bg-[#701C35] text-white text-xs sm:text-sm font-semibold px-6 py-3 rounded-full cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>Explore Our Latest Edit</span>
            </button>
          </div>
          <div className="rounded-2xl overflow-hidden aspect-[4/3] bg-[#F2E8DF]">
            <img
              src={GENERATED_ASSETS.heroBurgundy}
              alt="Urban by Grace Atelier Craftsmanship"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    );
  }

  if (pageId === 'contact') {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-3xl border border-[#281A1D]/10 p-6 sm:p-10 grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-5 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35]">
              CONCIERGE DESK
            </p>
            <h1 className="font-serif-display text-3xl font-semibold text-[#281A1D]">
              Contact Us
            </h1>
            <p className="text-sm text-[#77706D]">
              Our styling &amp; patron support team is available Monday through
              Saturday, 9:30 AM – 7:30 PM IST.
            </p>
            <div className="space-y-2.5 text-xs text-[#281A1D] pt-2">
              <p>
                <strong>Flagship Atelier:</strong> 14 Kala Ghoda Heritage
                Precinct, Fort, Mumbai — 400001
              </p>
              <p>
                <strong>Customer Care:</strong> care@urbanbygrace.in
              </p>
              <p>
                <strong>WhatsApp &amp; Phone:</strong> +91 22 4980 7700
              </p>
            </div>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setContactSent(true);
            }}
            className="md:col-span-7 space-y-4"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <input
                type="text"
                required
                value={contactForm.name}
                onChange={(e) =>
                  setContactForm({ ...contactForm, name: e.target.value })
                }
                placeholder="Your Full Name *"
                aria-label="Your Full Name"
                className="px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
              />
              <input
                type="email"
                required
                value={contactForm.email}
                onChange={(e) =>
                  setContactForm({ ...contactForm, email: e.target.value })
                }
                placeholder="Email Address *"
                aria-label="Email Address"
                className="px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
              />
            </div>
            <input
              type="text"
              value={contactForm.subject}
              onChange={(e) =>
                setContactForm({ ...contactForm, subject: e.target.value })
              }
              placeholder="Order ID or Styling Inquiry"
              aria-label="Subject"
              className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
            />
            <textarea
              rows={4}
              required
              value={contactForm.message}
              onChange={(e) =>
                setContactForm({ ...contactForm, message: e.target.value })
              }
              placeholder="How can we assist you today? *"
              aria-label="Message"
              className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white text-xs font-semibold cursor-pointer"
            >
              Send Message
            </button>
            {contactSent && (
              <p className="text-xs text-[#701C35] font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>
                  Thank you! Our concierge team will respond within 4 business
                  hours.
                </span>
              </p>
            )}
          </form>
        </div>
      </div>
    );
  }

  const POLICY_CONTENT: Record<
    string,
    { title: string; sections: { h: string; p: string }[] }
  > = {
    'shipping-policy': {
      title: 'Shipping & Delivery Policy',
      sections: [
        {
          h: '1. Complimentary Insured Shipping',
          p: 'Urban by Grace offers FREE standard shipping across all serviceable Indian pincodes on orders above ₹999. Orders below ₹999 incur a flat ₹99 shipping fee.',
        },
        {
          h: '2. Dispatch & Transit Timelines',
          p: 'Ready-to-ship styles are dispatched from our Mumbai and Jaipur fulfillment centers within 24–48 hours. Metro deliveries arrive in 2–3 business days; rest of India takes 4–6 business days.',
        },
      ],
    },
    'return-policy': {
      title: 'Return, Exchange & Refund Policy',
      sections: [
        {
          h: '1. Easy 7-Day Returns & Size Exchanges',
          p: 'We offer a hassle-free 7-day return and size exchange window from the date of delivery. Items must be unused, unwashed, and have all original Urban by Grace tags intact.',
        },
        {
          h: '2. Complimentary Reverse Pickup',
          p: 'Our courier partner will arrange a doorstep pickup within 48 hours of your return request. Refunds are processed to your original payment method or bank account within 3–5 business days.',
        },
      ],
    },
    'privacy-policy': {
      title: 'Privacy & Data Protection Policy',
      sections: [
        {
          h: '1. Patron Privacy Commitment',
          p: 'Urban by Grace respects your privacy and protects your personal contact, address, and transaction records using 256-bit SSL encryption.',
        },
        {
          h: '2. Zero Third-Party Data Selling',
          p: 'We never sell or rent patron data. Your phone number and email are used strictly for order updates and opt-inatelier previews.',
        },
      ],
    },
  };

  const policy = POLICY_CONTENT[pageId] || POLICY_CONTENT['shipping-policy'];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-3xl border border-[#281A1D]/10 p-6 sm:p-10 space-y-6">
        <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
          {policy.title}
        </h1>
        {policy.sections.map((sec, idx) => (
          <div key={idx} className="space-y-2">
            <h2 className="text-base font-semibold text-[#701C35]">{sec.h}</h2>
            <p className="text-sm text-[#77706D] leading-relaxed">{sec.p}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
