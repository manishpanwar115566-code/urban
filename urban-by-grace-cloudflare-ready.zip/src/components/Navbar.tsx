import React, { useState } from 'react';
import {
  Search,
  User,
  Heart,
  ShoppingBag,
  ChevronDown,
  Menu,
  X,
  Truck,
  RotateCcw,
  ShieldCheck,
  ArrowRight,
} from 'lucide-react';
import { PageId, Product } from '../types/store';
import { formatINR } from '../utils/commerce';

interface NavbarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onSelectProduct: (product: Product) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCartDrawer: () => void;
  products: Product[];
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onSelectProduct,
  cartCount,
  wishlistCount,
  onOpenCartDrawer,
  products,
  searchQuery,
  onSearchChange,
}) => {
  const [activeDropdown, setActiveDropdown] = useState<
    'women' | 'men' | 'collections' | null
  >(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const searchResults =
    searchQuery.trim().length > 0
      ? products
          .filter(
            (p) =>
              p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              p.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
              p.category.toLowerCase().includes(searchQuery.toLowerCase())
          )
          .slice(0, 5)
      : products.slice(0, 4);

  const handleNavClick = (page: PageId) => {
    setActiveDropdown(null);
    setMobileMenuOpen(false);
    onNavigate(page);
  };

  return (
    <>
      {/* 1. TOP ANNOUNCEMENT BAR */}
      <div className="bg-[#3D101D] text-white text-[11px] sm:text-xs py-2 px-4 border-b border-[#701C35]/40">
        <div className="max-w-[1360px] mx-auto flex flex-wrap items-center justify-center sm:justify-between gap-x-6 gap-y-1">
          <div className="flex items-center gap-1.5 whitespace-nowrap">
            <Truck className="w-3.5 h-3.5 text-[#E8C5CA] shrink-0" />
            <span>Free Shipping on Orders Above ₹999</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 whitespace-nowrap">
            <RotateCcw className="w-3.5 h-3.5 text-[#E8C5CA] shrink-0" />
            <span>Easy 7-Day Returns</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5 whitespace-nowrap">
            <ShieldCheck className="w-3.5 h-3.5 text-[#E8C5CA] shrink-0" />
            <span>100% Secure Payments</span>
          </div>
        </div>
      </div>

      {/* 2. MAIN STICKY NAVIGATION HEADER */}
      <header
        className="sticky top-0 z-40 bg-[#FAF5F0]/95 backdrop-blur-md border-b border-[#281A1D]/10 transition-all"
        onMouseLeave={() => setActiveDropdown(null)}
      >
        <div className="max-w-[1360px] mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between gap-2 sm:gap-4">
          {/* Left: Mobile Hamburger + Brand Logo */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
              className="lg:hidden p-1.5 -ml-1 text-[#281A1D] hover:text-[#701C35] transition-colors rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('home')}
              className="text-left group focus:outline-none"
            >
              <span className="font-serif-display text-xl sm:text-[28px] font-semibold tracking-tight text-[#281A1D] group-hover:text-[#701C35] transition-colors whitespace-nowrap">
                Urban <span className="italic font-normal text-[#701C35]">by</span> Grace
              </span>
            </button>
          </div>

          {/* Center: Desktop Navigation Links */}
          <nav
            aria-label="Main Navigation"
            className="hidden lg:flex items-center gap-7 text-sm font-medium text-[#281A1D]"
          >
            <button
              type="button"
              onClick={() => handleNavClick('home')}
              className={`py-2 transition-colors whitespace-nowrap relative ${
                currentPage === 'home'
                  ? 'text-[#701C35] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[2px] after:bg-[#701C35]'
                  : 'hover:text-[#701C35]'
              }`}
            >
              Home
            </button>

            {/* Women Dropdown Trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('women')}
            >
              <button
                type="button"
                onClick={() => handleNavClick('women')}
                aria-expanded={activeDropdown === 'women'}
                className={`flex items-center gap-1 py-2 transition-colors whitespace-nowrap ${
                  currentPage === 'women' ||
                  currentPage === 'kurtas-suits' ||
                  currentPage === 'dresses'
                    ? 'text-[#701C35] font-semibold'
                    : 'hover:text-[#701C35]'
                }`}
              >
                <span>Women</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-75" />
              </button>

              {activeDropdown === 'women' && (
                <div className="absolute top-full left-0 w-60 bg-white border border-[#281A1D]/10 rounded-xl shadow-xl py-3 px-2 z-50">
                  <p className="px-3 py-1.5 text-[11px] font-semibold tracking-wider text-[#77706D] uppercase">
                    Women&apos;s Edit
                  </p>
                  <button
                    type="button"
                    onClick={() => handleNavClick('kurtas-suits')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Kurtas &amp; Suit Sets
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('dresses')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Midi &amp; Maxi Dresses
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('coord-sets')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Tailored Co-ord Sets
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('tops-tees')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Shirts, Tops &amp; Tees
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('bags-accessories')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Bags &amp; Fine Accessories
                  </button>
                </div>
              )}
            </div>

            {/* Men Dropdown Trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('men')}
            >
              <button
                type="button"
                onClick={() => handleNavClick('men')}
                aria-expanded={activeDropdown === 'men'}
                className={`flex items-center gap-1 py-2 transition-colors whitespace-nowrap ${
                  currentPage === 'men'
                    ? 'text-[#701C35] font-semibold'
                    : 'hover:text-[#701C35]'
                }`}
              >
                <span>Men</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-75" />
              </button>

              {activeDropdown === 'men' && (
                <div className="absolute top-full left-0 w-56 bg-white border border-[#281A1D]/10 rounded-xl shadow-xl py-3 px-2 z-50">
                  <p className="px-3 py-1.5 text-[11px] font-semibold tracking-wider text-[#77706D] uppercase">
                    Men&apos;s Wardrobe
                  </p>
                  <button
                    type="button"
                    onClick={() => handleNavClick('men')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    All Men&apos;s Wear
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('ethnic-wear')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Festive Bandhgalas &amp; Kurtas
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('tops-tees')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Classic Poplin &amp; Linen Shirts
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => handleNavClick('new-arrivals')}
              className={`py-2 transition-colors whitespace-nowrap relative ${
                currentPage === 'new-arrivals'
                  ? 'text-[#701C35] font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-[2px] after:bg-[#701C35]'
                  : 'hover:text-[#701C35]'
              }`}
            >
              New Arrivals
            </button>

            {/* Collections Dropdown Trigger */}
            <div
              className="relative"
              onMouseEnter={() => setActiveDropdown('collections')}
            >
              <button
                type="button"
                onClick={() => handleNavClick('ethnic-wear')}
                aria-expanded={activeDropdown === 'collections'}
                className={`flex items-center gap-1 py-2 transition-colors whitespace-nowrap ${
                  currentPage === 'ethnic-wear' || currentPage === 'western-wear'
                    ? 'text-[#701C35] font-semibold'
                    : 'hover:text-[#701C35]'
                }`}
              >
                <span>Collections</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-75" />
              </button>

              {activeDropdown === 'collections' && (
                <div className="absolute top-full left-0 w-64 bg-white border border-[#281A1D]/10 rounded-xl shadow-xl py-3 px-2 z-50">
                  <p className="px-3 py-1.5 text-[11px] font-semibold tracking-wider text-[#77706D] uppercase">
                    Signature Edits
                  </p>
                  <button
                    type="button"
                    onClick={() => handleNavClick('ethnic-wear')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Elegant Ethnic Wear
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('western-wear')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Trendy Western Wear
                  </button>
                  <button
                    type="button"
                    onClick={() => handleNavClick('bags-accessories')}
                    className="w-full text-left px-3 py-2 text-sm text-[#281A1D] hover:bg-[#FAF5F0] hover:text-[#701C35] rounded-lg transition-colors"
                  >
                    Bridal Potlis &amp; Kundan Jewellery
                  </button>
                </div>
              )}
            </div>

            {/* Sale highlighted in pink per Brand Design System */}
            <button
              type="button"
              onClick={() => handleNavClick('sale')}
              className={`px-3 py-1 rounded-md text-sm font-semibold transition-colors whitespace-nowrap ${
                currentPage === 'sale'
                  ? 'bg-[#701C35] text-white'
                  : 'bg-[#E8C5CA]/75 text-[#701C35] hover:bg-[#E8C5CA]'
              }`}
            >
              Sale
            </button>
          </nav>

          {/* Right: Action Icons (Search, Account, Wishlist, Shopping Bag) */}
          <div className="flex items-center gap-0.5 sm:gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setSearchOpen(!searchOpen)}
              aria-label="Search products"
              className="p-2 sm:p-2.5 text-[#281A1D] hover:text-[#701C35] hover:bg-[#F2E8DF]/70 rounded-full transition-colors"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('account')}
              aria-label="My Account"
              className={`p-2 sm:p-2.5 rounded-full transition-colors ${
                currentPage === 'account'
                  ? 'bg-[#701C35] text-white'
                  : 'text-[#281A1D] hover:text-[#701C35] hover:bg-[#F2E8DF]/70'
              }`}
            >
              <User className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>

            <button
              type="button"
              onClick={() => handleNavClick('wishlist')}
              aria-label={`Wishlist (${wishlistCount} items)`}
              className={`relative p-2 sm:p-2.5 rounded-full transition-colors ${
                currentPage === 'wishlist'
                  ? 'bg-[#701C35] text-white'
                  : 'text-[#281A1D] hover:text-[#701C35] hover:bg-[#F2E8DF]/70'
              }`}
            >
              <Heart className="w-4 h-4 sm:w-5 sm:h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-[16px] sm:min-w-[18px] sm:h-[18px] px-1 rounded-full bg-[#701C35] text-white text-[10px] font-semibold flex items-center justify-center tabular-nums border border-[#FAF5F0]">
                  {wishlistCount}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={onOpenCartDrawer}
              aria-label={`Shopping bag (${cartCount} items)`}
              className="relative flex items-center gap-1 sm:gap-1.5 p-1.5 sm:p-2.5 text-[#281A1D] hover:text-[#701C35] hover:bg-[#F2E8DF]/70 rounded-full transition-colors"
            >
              <ShoppingBag className="w-4 h-4 sm:w-5 sm:h-5" />
              <span
                data-testid="header-cart-count"
                className="min-w-[18px] h-[18px] sm:min-w-[20px] sm:h-[20px] px-1 sm:px-1.5 rounded-full bg-[#701C35] text-white text-[10px] sm:text-[11px] font-semibold flex items-center justify-center tabular-nums"
              >
                {cartCount}
              </span>
            </button>
          </div>
        </div>

        {/* SEARCH OVERLAY DRAWER */}
        {searchOpen && (
          <div className="border-t border-[#281A1D]/10 bg-[#FAF5F0] shadow-xl py-6 px-4 sm:px-8">
            <div className="max-w-3xl mx-auto">
              <div className="relative flex items-center">
                <Search className="w-5 h-5 text-[#77706D] absolute left-4 pointer-events-none" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => onSearchChange(e.target.value)}
                  placeholder="Search for Embroidered Kurta Set, Floral Dress, Co-ord Set, Linen Shirt..."
                  aria-label="Search catalog"
                  autoFocus
                  className="w-full pl-12 pr-24 py-3.5 bg-white border border-[#281A1D]/20 rounded-xl text-sm text-[#281A1D] placeholder:text-[#77706D] focus:outline-none focus:border-[#701C35]"
                />
                <button
                  type="button"
                  onClick={() => setSearchOpen(false)}
                  className="absolute right-3 px-3 py-1.5 text-xs font-medium text-[#77706D] hover:text-[#281A1D]"
                >
                  Close
                </button>
              </div>

              <div className="mt-4">
                <p className="text-xs font-medium text-[#77706D] mb-3">
                  {searchQuery.trim()
                    ? `Matching Results (${searchResults.length})`
                    : 'Popular Searches in Urban by Grace'}
                </p>
                {searchResults.length === 0 ? (
                  <p className="text-sm text-[#77706D] py-4">
                    No matching styles found for &ldquo;{searchQuery}&rdquo;. Try searching &ldquo;Kurta&rdquo;, &ldquo;Dress&rdquo;, or &ldquo;Shirt&rdquo;.
                  </p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {searchResults.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setSearchOpen(false);
                          onSelectProduct(item);
                        }}
                        className="flex items-center gap-3 p-2.5 rounded-xl bg-white hover:bg-[#F2E8DF]/60 border border-[#281A1D]/8 transition-colors text-left"
                      >
                        <img
                          src={item.images[0]}
                          alt={item.name}
                          referrerPolicy="no-referrer"
                          className="w-12 h-14 object-cover rounded-lg bg-[#F2E8DF] shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium text-[#281A1D] truncate">
                            {item.name}
                          </p>
                          <p className="text-xs text-[#77706D] truncate">
                            {item.subtitle}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs font-semibold text-[#701C35] tabular-nums">
                              {formatINR(item.price)}
                            </span>
                            <span className="text-[11px] text-[#77706D] line-through tabular-nums">
                              {formatINR(item.originalPrice)}
                            </span>
                          </div>
                        </div>
                        <ArrowRight className="w-4 h-4 text-[#77706D] shrink-0" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* MOBILE HAMBURGER NAVIGATION MENU */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#FAF5F0] border-t border-[#281A1D]/10 px-4 py-5 space-y-2 shadow-xl max-h-[80vh] overflow-y-auto">
            {[
              { label: 'Home', page: 'home' as PageId },
              { label: 'Women Collection', page: 'women' as PageId },
              { label: 'Men Collection', page: 'men' as PageId },
              { label: 'New Arrivals', page: 'new-arrivals' as PageId },
              { label: 'Ethnic Wear', page: 'ethnic-wear' as PageId },
              { label: 'Western Wear', page: 'western-wear' as PageId },
              { label: 'Kurtas & Suits', page: 'kurtas-suits' as PageId },
              { label: 'Dresses', page: 'dresses' as PageId },
              { label: 'Co-ord Sets', page: 'coord-sets' as PageId },
              { label: 'Tops & Tees', page: 'tops-tees' as PageId },
              { label: 'Bags & Accessories', page: 'bags-accessories' as PageId },
              { label: 'Sale — Up to 40% Off', page: 'sale' as PageId },
              { label: 'My Account', page: 'account' as PageId },
              { label: 'About Us', page: 'about' as PageId },
              { label: 'Contact Us', page: 'contact' as PageId },
            ].map((nav) => (
              <button
                key={nav.page}
                type="button"
                onClick={() => handleNavClick(nav.page)}
                className={`w-full text-left px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  currentPage === nav.page
                    ? 'bg-[#701C35] text-white'
                    : nav.page === 'sale'
                    ? 'bg-[#E8C5CA]/70 text-[#701C35] font-semibold'
                    : 'text-[#281A1D] hover:bg-[#F2E8DF]'
                }`}
              >
                {nav.label}
              </button>
            ))}
          </div>
        )}
      </header>
    </>
  );
};
