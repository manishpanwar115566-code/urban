import {
  CartItem,
  CartSummary,
  CheckoutInput,
  FilterOptions,
  PincodeCheckResult,
  Product,
} from '../types/store';

export const FREE_SHIPPING_THRESHOLD = 999;
export const STANDARD_SHIPPING_FEE = 99;

export const VALID_COUPONS: Record<
  string,
  {
    code: string;
    type: 'percent' | 'flat';
    value: number;
    minSubtotal: number;
    maxDiscount?: number;
    description: string;
  }
> = {
  GRACE10: {
    code: 'GRACE10',
    type: 'percent',
    value: 10,
    minSubtotal: 999,
    maxDiscount: 750,
    description: '10% off on orders above ₹999',
  },
  URBAN15: {
    code: 'URBAN15',
    type: 'percent',
    value: 15,
    minSubtotal: 2499,
    maxDiscount: 1200,
    description: '15% off on orders above ₹2,499',
  },
  ROYAL300: {
    code: 'ROYAL300',
    type: 'flat',
    value: 300,
    minSubtotal: 1999,
    description: 'Flat ₹300 off on orders above ₹1,999',
  },
};

export function formatINR(amount: number): string {
  const rounded = Math.round(amount);
  return `₹${rounded.toLocaleString('en-IN')}`;
}

export function calculateDiscountPercent(
  price: number,
  originalPrice: number
): number {
  if (originalPrice <= 0 || price >= originalPrice) return 0;
  return Math.round(((originalPrice - price) / originalPrice) * 100);
}

export function calculateCartSummary(
  items: CartItem[],
  rawCouponCode?: string | null
): CartSummary {
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const mrpTotal = items.reduce(
    (sum, item) => sum + item.product.originalPrice * item.quantity,
    0
  );
  const subtotal = items.reduce(
    (sum, item) => sum + item.product.price * item.quantity,
    0
  );
  const productDiscount = Math.max(0, mrpTotal - subtotal);

  let couponCode: string | null = null;
  let couponDiscount = 0;

  if (rawCouponCode && subtotal > 0) {
    const normalized = rawCouponCode.trim().toUpperCase();
    const coupon = VALID_COUPONS[normalized];
    if (coupon && subtotal >= coupon.minSubtotal) {
      couponCode = coupon.code;
      if (coupon.type === 'percent') {
        const rawDisc = Math.round((subtotal * coupon.value) / 100);
        couponDiscount = coupon.maxDiscount
          ? Math.min(rawDisc, coupon.maxDiscount)
          : rawDisc;
      } else {
        couponDiscount = Math.min(subtotal, coupon.value);
      }
    }
  }

  const discountedSubtotal = Math.max(0, subtotal - couponDiscount);
  const shippingFee =
    itemCount === 0 || discountedSubtotal >= FREE_SHIPPING_THRESHOLD
      ? 0
      : STANDARD_SHIPPING_FEE;

  const freeShippingRemaining =
    discountedSubtotal >= FREE_SHIPPING_THRESHOLD
      ? 0
      : Math.max(0, FREE_SHIPPING_THRESHOLD - discountedSubtotal);

  const payableAmount =
    itemCount === 0 ? 0 : discountedSubtotal + shippingFee;

  return {
    itemCount,
    mrpTotal,
    productDiscount,
    subtotal,
    couponCode,
    couponDiscount,
    shippingFee,
    freeShippingRemaining,
    payableAmount,
  };
}

export function validateCouponCode(
  rawCode: string,
  subtotal: number
): { valid: boolean; message: string; code?: string } {
  const normalized = rawCode.trim().toUpperCase();
  if (!normalized) {
    return { valid: false, message: 'Please enter a coupon code.' };
  }
  const coupon = VALID_COUPONS[normalized];
  if (!coupon) {
    return {
      valid: false,
      message: 'Invalid coupon code. Try GRACE10, URBAN15, or ROYAL300.',
    };
  }
  if (subtotal < coupon.minSubtotal) {
    return {
      valid: false,
      message: `Add ${formatINR(coupon.minSubtotal - subtotal)} more to unlock ${coupon.code}.`,
    };
  }
  return {
    valid: true,
    code: coupon.code,
    message: `${coupon.code} applied! (${coupon.description})`,
  };
}

const PINCODE_PREFIX_REGIONS: Record<
  string,
  { city: string; state: string; days: string; express: boolean }
> = {
  '11': { city: 'New Delhi', state: 'Delhi NCR', days: '2–3 Days', express: true },
  '12': { city: 'Gurugram / Faridabad', state: 'Haryana', days: '2–3 Days', express: true },
  '20': { city: 'Noida / Lucknow', state: 'Uttar Pradesh', days: '3–4 Days', express: true },
  '30': { city: 'Jaipur', state: 'Rajasthan', days: '2–4 Days', express: true },
  '38': { city: 'Ahmedabad', state: 'Gujarat', days: '3–4 Days', express: true },
  '40': { city: 'Mumbai', state: 'Maharashtra', days: '2–3 Days', express: true },
  '41': { city: 'Pune', state: 'Maharashtra', days: '2–3 Days', express: true },
  '50': { city: 'Hyderabad', state: 'Telangana', days: '3–4 Days', express: true },
  '56': { city: 'Bengaluru', state: 'Karnataka', days: '2–3 Days', express: true },
  '60': { city: 'Chennai', state: 'Tamil Nadu', days: '3–5 Days', express: true },
  '70': { city: 'Kolkata', state: 'West Bengal', days: '3–5 Days', express: true },
};

export function checkPincodeDelivery(rawPincode: string): PincodeCheckResult {
  const cleaned = rawPincode.trim();
  if (!/^[1-9][0-9]{5}$/.test(cleaned)) {
    return {
      valid: false,
      pincode: cleaned,
      error: 'Please enter a valid 6-digit Indian pincode (e.g. 400001, 110001).',
    };
  }

  const prefix = cleaned.slice(0, 2);
  const region = PINCODE_PREFIX_REGIONS[prefix] || {
    city: 'Serviceable Metro / Tier-1 Hub',
    state: 'India',
    days: '4–6 Days',
    express: false,
  };

  return {
    valid: true,
    pincode: cleaned,
    city: region.city,
    state: region.state,
    estimatedDays: region.days,
    deliveryDateLabel: `Estimated Delivery in ${region.days}`,
    codAvailable: true,
    expressAvailable: region.express,
  };
}

export function filterAndSortProducts(
  products: Product[],
  options: FilterOptions
): Product[] {
  let result = [...products];

  // Page-level filter
  if (options.pageId) {
    switch (options.pageId) {
      case 'women':
        result = result.filter((p) => p.gender === 'women' || p.gender === 'unisex');
        break;
      case 'men':
        result = result.filter((p) => p.gender === 'men');
        break;
      case 'new-arrivals':
        result = result.filter((p) => p.isNewArrival);
        break;
      case 'ethnic-wear':
        result = result.filter((p) => p.collection === 'ethnic');
        break;
      case 'western-wear':
        result = result.filter((p) => p.collection === 'western');
        break;
      case 'dresses':
        result = result.filter((p) => p.category === 'dresses');
        break;
      case 'kurtas-suits':
        result = result.filter(
          (p) => p.category === 'kurtas-suits' || p.category === 'ethnic-wear'
        );
        break;
      case 'tops-tees':
        result = result.filter((p) => p.category === 'tops-tees');
        break;
      case 'coord-sets':
        result = result.filter((p) => p.category === 'coord-sets');
        break;
      case 'bags-accessories':
        result = result.filter((p) => p.category === 'bags-accessories');
        break;
      case 'sale':
        result = result.filter((p) => p.isOnSale || p.discountPercent >= 20);
        break;
      default:
        break;
    }
  }

  if (options.selectedCategory && options.selectedCategory !== 'all') {
    result = result.filter((p) => p.category === options.selectedCategory);
  }

  if (options.selectedSize && options.selectedSize !== 'ALL') {
    result = result.filter((p) => p.sizes.includes(options.selectedSize as any));
  }

  if (options.priceRange && options.priceRange !== 'all') {
    if (options.priceRange === 'under-1500') {
      result = result.filter((p) => p.price < 1500);
    } else if (options.priceRange === '1500-2500') {
      result = result.filter((p) => p.price >= 1500 && p.price <= 2500);
    } else if (options.priceRange === 'above-2500') {
      result = result.filter((p) => p.price > 2500);
    }
  }

  if (options.searchQuery && options.searchQuery.trim().length > 0) {
    const q = options.searchQuery.trim().toLowerCase();
    result = result.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.collection.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }

  if (options.sortBy) {
    switch (options.sortBy) {
      case 'price-asc':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'discount':
        result.sort((a, b) => b.discountPercent - a.discountPercent);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }
  }

  return result;
}

export function validateCheckoutForm(input: CheckoutInput): {
  valid: boolean;
  errors: Record<string, string>;
} {
  const errors: Record<string, string> = {};

  if (!input.fullName || input.fullName.trim().length < 2) {
    errors.fullName = 'Please enter your full name.';
  }
  if (!input.email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }
  if (!input.phone || !/^[6-9]\d{9}$/.test(input.phone.trim())) {
    errors.phone = 'Please enter a valid 10-digit Indian mobile number.';
  }
  if (!input.addressLine1 || input.addressLine1.trim().length < 5) {
    errors.addressLine1 = 'Please enter your complete street/house address.';
  }
  if (!input.city || input.city.trim().length < 2) {
    errors.city = 'Please enter your city.';
  }
  if (!input.state || input.state.trim().length < 2) {
    errors.state = 'Please select or enter your state.';
  }
  if (!input.pincode || !/^[1-9][0-9]{5}$/.test(input.pincode.trim())) {
    errors.pincode = 'Please enter a valid 6-digit Indian pincode.';
  }
  if (
    input.paymentMethod === 'upi' &&
    (!input.upiId || !input.upiId.includes('@'))
  ) {
    errors.upiId = 'Please enter a valid UPI ID (e.g. name@okaxis).';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}
