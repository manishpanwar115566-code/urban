import React, { useState, useEffect } from 'react';
import {
  X,
  Heart,
  ShoppingBag,
  Star,
  CheckCircle2,
  ZoomIn,
  ZoomOut,
  ArrowRight,
  Truck,
  RotateCcw,
} from 'lucide-react';
import { Product, SizeOption } from '../types/store';
import { formatINR } from '../utils/commerce';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (
    product: Product,
    size: SizeOption,
    color: string,
    quantity: number
  ) => void;
  onViewFullDetails: (product: Product) => void;
}

const ALL_SIZES: SizeOption[] = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export const QuickViewModal: React.FC<QuickViewModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onViewFullDetails,
}) => {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<SizeOption>('M');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [isZoomed, setIsZoomed] = useState<boolean>(true);
  const [zoomOrigin, setZoomOrigin] = useState<{ x: number; y: number }>({
    x: 50,
    y: 25,
  });
  const [addedFeedback, setAddedFeedback] = useState<boolean>(false);

  useEffect(() => {
    if (product) {
      setSelectedImageIdx(0);
      setSelectedSize(
        product.sizes.includes('M') ? 'M' : product.sizes[0] || 'M'
      );
      setSelectedColor(product.colors[0]?.name || 'Default');
      setQuantity(1);
      setIsZoomed(true);
      setZoomOrigin({ x: 50, y: 25 });
      setAddedFeedback(false);
    }
  }, [product]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !product) return null;

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isZoomed) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setZoomOrigin({
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y)),
    });
  };

  const handleAdd = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Quick View: ${product.name}`}
      data-testid="quick-view-modal"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl bg-[#FAF5F0] rounded-3xl border border-[#281A1D]/15 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col md:flex-row"
      >
        {/* Close Modal Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close quick view modal"
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/90 hover:bg-[#701C35] text-[#281A1D] hover:text-white flex items-center justify-center shadow-md transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Zoomed-In Image Viewer & Thumbnails */}
        <div className="md:w-1/2 bg-[#F2E8DF] flex flex-col justify-between p-4 sm:p-6 border-b md:border-b-0 md:border-r border-[#281A1D]/10">
          <div
            onMouseMove={handleMouseMove}
            onClick={() => setIsZoomed((z) => !z)}
            className={`relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-[#E9DDD0] border border-[#281A1D]/10 ${
              isZoomed ? 'cursor-zoom-out' : 'cursor-zoom-in'
            }`}
          >
            <img
              src={product.images[selectedImageIdx] || product.images[0]}
              alt={`${product.name} zoomed preview`}
              referrerPolicy="no-referrer"
              style={{
                objectPosition: product.imagePosition || 'center top',
                transformOrigin: `${zoomOrigin.x}% ${zoomOrigin.y}%`,
              }}
              className={`w-full h-full object-cover transition-transform duration-300 ${
                isZoomed ? 'scale-125' : product.imageScale || 'scale-100'
              }`}
            />

            {/* Zoom Status Toggle Pill */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsZoomed((z) => !z);
              }}
              aria-label={isZoomed ? 'Reset image zoom' : 'Zoom in on image'}
              className="absolute bottom-3 left-3 px-3 py-1.5 rounded-full bg-white/90 hover:bg-white text-[#281A1D] text-[11px] font-semibold flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              {isZoomed ? (
                <>
                  <ZoomOut className="w-3.5 h-3.5 text-[#701C35]" />
                  <span>Zoomed 1.25× (Click to Reset)</span>
                </>
              ) : (
                <>
                  <ZoomIn className="w-3.5 h-3.5 text-[#701C35]" />
                  <span>Click to Zoom Detail</span>
                </>
              )}
            </button>

            {/* Wishlist Toggle on Image */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onToggleWishlist(product);
              }}
              aria-label={
                isWishlisted
                  ? `Remove ${product.name} from wishlist`
                  : `Add ${product.name} to wishlist`
              }
              className={`absolute top-3 left-3 w-9 h-9 rounded-full flex items-center justify-center shadow-sm transition-colors cursor-pointer ${
                isWishlisted
                  ? 'bg-[#701C35] text-white'
                  : 'bg-white/90 hover:bg-white text-[#281A1D] hover:text-[#701C35]'
              }`}
            >
              <Heart
                className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`}
              />
            </button>
          </div>

          {/* Thumbnail Strip */}
          {product.images.length > 1 && (
            <div className="flex items-center justify-center gap-2.5 mt-3">
              {product.images.map((imgUrl, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSelectedImageIdx(idx)}
                  aria-label={`Select preview image ${idx + 1}`}
                  className={`w-14 h-18 rounded-lg overflow-hidden border-2 transition-all cursor-pointer bg-white ${
                    selectedImageIdx === idx
                      ? 'border-[#701C35] scale-105 shadow-xs'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={imgUrl}
                    alt={`${product.name} thumbnail ${idx + 1}`}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Key Product Details & Add-to-Cart Controls */}
        <div className="md:w-1/2 p-5 sm:p-7 overflow-y-auto space-y-5 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#701C35]">
                URBAN BY GRACE · QUICK VIEW
              </p>
              <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold text-[#281A1D] mt-1 pr-8">
                {product.name}
              </h2>
              <p className="text-xs sm:text-sm text-[#77706D] mt-0.5">
                {product.subtitle}
              </p>

              <div className="flex items-center gap-2 mt-2 text-xs">
                <span className="inline-flex items-center gap-1 font-semibold text-[#701C35]">
                  <Star className="w-3.5 h-3.5 fill-current" />
                  <span className="tabular-nums">
                    {product.rating.toFixed(1)}
                  </span>
                </span>
                <span aria-hidden="true" className="text-[#77706D]">
                  ·
                </span>
                <span className="text-[#77706D] tabular-nums">
                  {product.reviewCount} Verified Reviews
                </span>
                <span aria-hidden="true" className="text-[#77706D]">
                  ·
                </span>
                <span className="text-[#77706D]">SKU: {product.sku}</span>
              </div>
            </div>

            {/* Pricing Block */}
            <div className="p-3.5 rounded-xl bg-[#F2E8DF]/75 border border-[#281A1D]/10 flex items-baseline flex-wrap gap-2.5">
              <span className="text-2xl font-bold text-[#281A1D] tabular-nums">
                {formatINR(product.price)}
              </span>
              <span className="text-sm text-[#77706D] line-through tabular-nums">
                MRP {formatINR(product.originalPrice)}
              </span>
              <span className="text-xs font-semibold text-[#701C35] tabular-nums">
                ({product.discountPercent}% OFF)
              </span>
            </div>

            {/* Key Description & Fabric Highlights */}
            <p className="text-xs sm:text-sm text-[#281A1D]/85 leading-relaxed line-clamp-3">
              {product.description}
            </p>

            {/* Color Selection */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#281A1D] mb-2">
                Color:{' '}
                <span className="font-normal text-[#77706D]">
                  {selectedColor}
                </span>
              </p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c.name}
                    type="button"
                    onClick={() => setSelectedColor(c.name)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all cursor-pointer ${
                      selectedColor === c.name
                        ? 'border-[#701C35] bg-white text-[#701C35] ring-1 ring-[#701C35]'
                        : 'border-[#281A1D]/15 bg-white/70 text-[#281A1D] hover:border-[#701C35]/50'
                    }`}
                  >
                    <span
                      className="w-3.5 h-3.5 rounded-full border border-black/20"
                      style={{ backgroundColor: c.hex }}
                    />
                    <span>{c.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selection */}
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-[#281A1D] mb-2">
                Select Size:{' '}
                <span className="text-[#701C35]">{selectedSize}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {ALL_SIZES.map((sz) => {
                  const available = product.sizes.includes(sz);
                  const active = selectedSize === sz;
                  return (
                    <button
                      key={sz}
                      type="button"
                      disabled={!available}
                      onClick={() => setSelectedSize(sz)}
                      aria-label={`Quick view size ${sz}`}
                      className={`w-10 h-10 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                        active
                          ? 'bg-[#701C35] text-white shadow-xs'
                          : available
                          ? 'bg-white border border-[#281A1D]/20 text-[#281A1D] hover:border-[#701C35]'
                          : 'bg-[#F2E8DF]/50 border border-[#281A1D]/10 text-[#77706D]/40 line-through cursor-not-allowed'
                      }`}
                    >
                      {sz}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Bottom Action Bar: Quantity + Add to Cart + View Full Details */}
          <div className="pt-4 border-t border-[#281A1D]/10 space-y-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center border border-[#281A1D]/20 rounded-xl bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  aria-label="Decrease quick view quantity"
                  className="w-9 h-11 text-base font-medium text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                >
                  −
                </button>
                <span className="w-8 text-center text-xs font-semibold tabular-nums">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                  aria-label="Increase quick view quantity"
                  className="w-9 h-11 text-base font-medium text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                >
                  +
                </button>
              </div>

              <button
                type="button"
                onClick={handleAdd}
                className="flex-1 py-3 px-5 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>
                  Add to Cart — {formatINR(product.price * quantity)}
                </span>
              </button>
            </div>

            {addedFeedback && (
              <div
                role="status"
                className="flex items-center gap-2 p-2.5 rounded-xl bg-[#701C35]/10 border border-[#701C35]/30 text-xs font-medium text-[#701C35]"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  Added {quantity} × {product.name} (Size {selectedSize}) to your
                  bag!
                </span>
              </div>
            )}

            <div className="flex items-center justify-between pt-1 text-xs">
              <div className="flex items-center gap-3 text-[#77706D]">
                <span className="inline-flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-[#701C35]" />
                  <span>Free Shipping ₹999+</span>
                </span>
                <span className="inline-flex items-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-[#701C35]" />
                  <span>7-Day Returns</span>
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onViewFullDetails(product);
                }}
                className="inline-flex items-center gap-1 font-semibold text-[#701C35] hover:underline cursor-pointer whitespace-nowrap"
              >
                <span>Full Details</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
