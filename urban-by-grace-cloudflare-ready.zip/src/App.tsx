import React, { useState, useEffect, useMemo } from 'react';
import { ArrowRight } from 'lucide-react';
import {
  CartItem,
  CheckoutInput,
  OrderRecord,
  PageId,
  Product,
  SizeOption,
} from './types/store';
import { PRODUCTS } from './data/catalog';
import { calculateCartSummary } from './utils/commerce';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { CategoryStrip } from './components/CategoryStrip';
import { CollectionBanners } from './components/CollectionBanners';
import { ProductCard } from './components/ProductCard';
import { ProductDetailsView } from './components/ProductDetailsView';
import {
  CartDrawer,
  CartPageView,
  CheckoutView,
  OrderConfirmationView,
} from './components/CartAndCheckoutViews';
import {
  AccountView,
  CatalogListingView,
  EditorialPageView,
  WishlistView,
} from './components/StorePages';
import { QuickViewModal } from './components/QuickViewModal';
import { Footer } from './components/Footer';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product>(PRODUCTS[0]);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(
    null
  );
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [cartDrawerOpen, setCartDrawerOpen] = useState<boolean>(false);

  // Persistent Wishlist State
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('ubg_wishlist');
      return saved ? JSON.parse(saved) : ['ubg-1'];
    } catch {
      return ['ubg-1'];
    }
  });

  // Persistent Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ubg_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [latestOrder, setLatestOrder] = useState<OrderRecord | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('ubg_wishlist', JSON.stringify(wishlistIds));
    } catch {
      // ignore storage errors
    }
  }, [wishlistIds]);

  useEffect(() => {
    try {
      localStorage.setItem('ubg_cart', JSON.stringify(cartItems));
    } catch {
      // ignore storage errors
    }
  }, [cartItems]);

  const cartSummary = useMemo(
    () => calculateCartSummary(cartItems, appliedCoupon),
    [cartItems, appliedCoupon]
  );

  const handleNavigate = (page: PageId) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage('product-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleWishlist = (product: Product) => {
    setWishlistIds((prev) =>
      prev.includes(product.id)
        ? prev.filter((id) => id !== product.id)
        : [...prev, product.id]
    );
  };

  const handleAddToCart = (
    product: Product,
    size: SizeOption,
    color: string,
    quantity: number
  ) => {
    setCartItems((prev) => {
      const idx = prev.findIndex(
        (item) =>
          item.product.id === product.id &&
          item.size === size &&
          item.color === color
      );
      if (idx > -1) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          quantity: updated[idx].quantity + quantity,
        };
        return updated;
      }
      return [...prev, { product, size, color, quantity }];
    });
  };

  const handleQuickAddToCart = (product: Product) => {
    handleAddToCart(
      product,
      product.sizes.includes('M') ? 'M' : product.sizes[0] || 'M',
      product.colors[0]?.name || 'Default',
      1
    );
  };

  const handleBuyNow = (
    product: Product,
    size: SizeOption,
    color: string,
    quantity: number
  ) => {
    handleAddToCart(product, size, color, quantity);
    handleNavigate('checkout');
  };

  const handleUpdateQty = (
    productId: string,
    size: SizeOption,
    color: string,
    delta: number
  ) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (
            item.product.id === productId &&
            item.size === size &&
            item.color === color
          ) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (
    productId: string,
    size: SizeOption,
    color: string
  ) => {
    setCartItems((prev) =>
      prev.filter(
        (item) =>
          !(
            item.product.id === productId &&
            item.size === size &&
            item.color === color
          )
      )
    );
  };

  const handlePlaceOrder = (customer: CheckoutInput) => {
    const newOrder: OrderRecord = {
      orderId: `UBG-${Math.floor(100000 + Math.random() * 900000)}`,
      placedAt: new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      }),
      items: [...cartItems],
      summary: cartSummary,
      customer,
      estimatedDelivery: 'Within 2–4 Business Days',
      status: 'Confirmed',
    };
    setOrders((prev) => [newOrder, ...prev]);
    setLatestOrder(newOrder);
    setCartItems([]);
    setAppliedCoupon(null);
    handleNavigate('order-confirmation');
  };

  // Exact 5 New Arrivals for the Home Page 5-Column Grid
  const newArrivalFiveProducts = useMemo(
    () => PRODUCTS.filter((p) => p.isNewArrival).slice(0, 5),
    []
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF5F0] text-[#281A1D]">
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onSelectProduct={handleSelectProduct}
        cartCount={cartSummary.itemCount}
        wishlistCount={wishlistIds.length}
        onOpenCartDrawer={() => setCartDrawerOpen(true)}
        products={PRODUCTS}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      <main className="flex-1">
        {currentPage === 'home' && (
          <>
            {/* 1. LUXURY EDITORIAL HERO BANNER */}
            <HeroBanner onNavigate={handleNavigate} />

            {/* 2. SHOP BY CATEGORY (8 Circular Categories) */}
            <CategoryStrip onNavigate={handleNavigate} />

            {/* 3. FEATURED COLLECTION BANNERS (Ethnic & Western) + 4-COLUMN SHOPPING BENEFITS */}
            <CollectionBanners onNavigate={handleNavigate} />

            {/* 4. NEW ARRIVALS PRODUCT SECTION (Centered Heading with Decorative Lines & 5-Column Grid) */}
            <section
              aria-labelledby="new-arrivals-heading"
              className="py-10 sm:py-14 bg-[#FAF5F0]"
            >
              <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
                {/* Centered Heading with Thin Decorative Horizontal Lines on Both Sides */}
                <div className="flex items-center justify-center gap-4 sm:gap-6 mb-8 sm:mb-10">
                  <div
                    aria-hidden="true"
                    className="h-[1px] flex-1 max-w-[140px] sm:max-w-[220px] bg-gradient-to-r from-transparent to-[#281A1D]/30"
                  />
                  <h2
                    id="new-arrivals-heading"
                    className="font-serif-display text-2xl sm:text-3xl lg:text-[34px] font-semibold tracking-[0.14em] text-[#281A1D] uppercase text-center whitespace-nowrap"
                  >
                    NEW ARRIVALS
                  </h2>
                  <div
                    aria-hidden="true"
                    className="h-[1px] flex-1 max-w-[140px] sm:max-w-[220px] bg-gradient-to-l from-transparent to-[#281A1D]/30"
                  />
                </div>

                {/* Five-Column Product Grid on Desktop, 3 on Tablet, 2 on Mobile */}
                <div
                  data-testid="new-arrivals-grid"
                  className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6"
                >
                  {newArrivalFiveProducts.map((product) => (
                    <ProductCard
                      key={product.id}
                      product={product}
                      isWishlisted={wishlistIds.includes(product.id)}
                      onToggleWishlist={handleToggleWishlist}
                      onQuickAddToCart={handleQuickAddToCart}
                      onSelectProduct={handleSelectProduct}
                      onQuickView={setQuickViewProduct}
                    />
                  ))}
                </div>

                {/* View Complete Collection Link */}
                <div className="mt-10 text-center">
                  <button
                    type="button"
                    onClick={() => handleNavigate('new-arrivals')}
                    className="inline-flex items-center gap-2 px-7 py-3 rounded-full border border-[#701C35] text-[#701C35] hover:bg-[#701C35] hover:text-white text-xs sm:text-sm font-semibold transition-all cursor-pointer"
                  >
                    <span>Explore All New Season Styles</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </section>
          </>
        )}

        {/* COLLECTION & CATEGORY PAGES */}
        {(currentPage === 'women' ||
          currentPage === 'men' ||
          currentPage === 'new-arrivals' ||
          currentPage === 'ethnic-wear' ||
          currentPage === 'western-wear' ||
          currentPage === 'dresses' ||
          currentPage === 'kurtas-suits' ||
          currentPage === 'tops-tees' ||
          currentPage === 'coord-sets' ||
          currentPage === 'bags-accessories' ||
          currentPage === 'sale') && (
          <CatalogListingView
            pageId={currentPage}
            products={PRODUCTS}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onQuickAddToCart={handleQuickAddToCart}
            onSelectProduct={handleSelectProduct}
            onQuickView={setQuickViewProduct}
          />
        )}

        {/* PRODUCT DETAILS PAGE */}
        {currentPage === 'product-details' && (
          <ProductDetailsView
            product={selectedProduct}
            allProducts={PRODUCTS}
            isWishlisted={wishlistIds.includes(selectedProduct.id)}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
            onSelectProduct={handleSelectProduct}
            onBack={() => handleNavigate('home')}
            onQuickView={setQuickViewProduct}
          />
        )}

        {/* WISHLIST PAGE */}
        {currentPage === 'wishlist' && (
          <WishlistView
            products={PRODUCTS}
            wishlistIds={wishlistIds}
            onToggleWishlist={handleToggleWishlist}
            onQuickAddToCart={handleQuickAddToCart}
            onSelectProduct={handleSelectProduct}
            onNavigate={handleNavigate}
            onQuickView={setQuickViewProduct}
          />
        )}

        {/* SHOPPING CART PAGE */}
        {currentPage === 'cart' && (
          <CartPageView
            items={cartItems}
            summary={cartSummary}
            appliedCoupon={appliedCoupon}
            onApplyCoupon={setAppliedCoupon}
            onUpdateQty={handleUpdateQty}
            onRemoveItem={handleRemoveCartItem}
            onNavigate={handleNavigate}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {/* CHECKOUT PAGE */}
        {currentPage === 'checkout' && (
          <CheckoutView
            items={cartItems}
            summary={cartSummary}
            onPlaceOrder={handlePlaceOrder}
            onBackToCart={() => handleNavigate('cart')}
          />
        )}

        {/* ORDER CONFIRMATION PAGE */}
        {currentPage === 'order-confirmation' && latestOrder && (
          <OrderConfirmationView
            order={latestOrder}
            onContinueShopping={() => handleNavigate('home')}
          />
        )}

        {/* MY ACCOUNT PAGE */}
        {currentPage === 'account' && (
          <AccountView orders={orders} onNavigate={handleNavigate} />
        )}

        {/* ABOUT, CONTACT & POLICY PAGES */}
        {(currentPage === 'about' ||
          currentPage === 'contact' ||
          currentPage === 'privacy-policy' ||
          currentPage === 'shipping-policy' ||
          currentPage === 'return-policy') && (
          <EditorialPageView
            pageId={currentPage}
            onNavigate={handleNavigate}
          />
        )}
      </main>

      {/* Quick-View Modal for Product Grid Items */}
      <QuickViewModal
        product={quickViewProduct}
        isOpen={Boolean(quickViewProduct)}
        onClose={() => setQuickViewProduct(null)}
        isWishlisted={
          quickViewProduct ? wishlistIds.includes(quickViewProduct.id) : false
        }
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onViewFullDetails={handleSelectProduct}
      />

      {/* Slide-Over Shopping Bag Drawer */}
      <CartDrawer
        isOpen={cartDrawerOpen}
        onClose={() => setCartDrawerOpen(false)}
        items={cartItems}
        summary={cartSummary}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveCartItem}
        onGoToCart={() => handleNavigate('cart')}
        onGoToCheckout={() => handleNavigate('checkout')}
      />

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
