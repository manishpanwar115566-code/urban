import React from 'react';
import { SHOP_CATEGORIES } from '../data/catalog';
import { PageId } from '../types/store';

interface CategoryStripProps {
  onNavigate: (page: PageId) => void;
}

export const CategoryStrip: React.FC<CategoryStripProps> = ({ onNavigate }) => {
  return (
    <section
      aria-label="Shop by Category"
      className="py-8 sm:py-10 bg-[#FAF5F0]"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4 sm:gap-6 lg:gap-8 overflow-x-auto no-scrollbar pb-2 lg:justify-between">
          {SHOP_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => onNavigate(cat.pageId)}
              className="group flex flex-col items-center shrink-0 w-24 sm:w-28 lg:w-32 focus:outline-none cursor-pointer"
            >
              <div
                className={`w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 rounded-full p-1 transition-all duration-300 ${
                  cat.pageId === 'sale'
                    ? 'bg-[#E8C5CA] ring-2 ring-[#701C35]/40'
                    : 'bg-[#F2E8DF] ring-1 ring-[#281A1D]/15 group-hover:ring-[#701C35]'
                } overflow-hidden shadow-xs group-hover:shadow-md`}
              >
                <div className="w-full h-full rounded-full overflow-hidden bg-[#E9DDD0] relative">
                  <img
                    src={cat.image}
                    alt={cat.name}
                    referrerPolicy="no-referrer"
                    style={{ objectPosition: cat.imagePosition || 'center top' }}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  {cat.pageId === 'sale' && (
                    <div className="absolute inset-0 bg-[#701C35]/20 flex items-end justify-center pb-1.5">
                      <span className="text-[10px] font-bold tracking-wider uppercase bg-[#701C35] text-white px-2 py-0.5 rounded-full">
                        Sale
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <span className="mt-2.5 text-xs sm:text-[13px] font-medium text-[#281A1D] group-hover:text-[#701C35] transition-colors text-center whitespace-nowrap">
                {cat.name}
              </span>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
