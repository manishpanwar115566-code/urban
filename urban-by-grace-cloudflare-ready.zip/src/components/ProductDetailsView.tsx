import React, { useState } from 'react';
import {
  ArrowLeft,
  Heart,
  ShoppingBag,
  Zap,
  Star,
  Truck,
  RotateCcw,
  ShieldCheck,
  MapPin,
  CheckCircle2,
  Ruler,
  X,
} from 'lucide-react';
import {
  PincodeCheckResult,
  Product,
  ProductReview,
  SizeOption,
} from '../types/store';
import { checkPincodeDelivery, formatINR } from '../utils/commerce';
import { ProductCard } from './ProductCard';

interface ProductDetailsViewProps {
  product: Product;
  allProducts: Product[];
  isWishlisted: boolean;
  wishlistIds: string[];
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (
    product: Product,
    size: SizeOption,
    color: string,
    quantity: number
  ) => void;
  onBuyNow: (
    product: Product,
    size: SizeOption,
    color: string,
    quantity: number
  ) => void;
  onSelectProduct: (product: Product) => void;
  onBack: () => void;
  onQuickView?: (product: Product) => void;
}

const ALL_SIZES: SizeOption[] = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];

export const ProductDetailsView: React.FC<ProductDetailsViewProps> = ({
  product,
  allProducts,
  isWishlisted,
  wishlistIds,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onSelectProduct,
  onBack,
  onQuickView,
}) => {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<SizeOption>(
    product.sizes.includes('M') ? 'M' : product.sizes[0] || 'M'
  );
  const [selectedColor, setSelectedColor] = useState<string>(
    product.colors[0]?.name || 'Default'
  );
  const [quantity, setQuantity] = useState<number>(1);
  const [pincode, setPincode] = useState<string>('');
  const [pincodeResult, setPincodeResult] =
    useState<PincodeCheckResult | null>(null);
  const [activeTab, setActiveTab] = useState<
    'description' | 'fabric' | 'returns'
  >('description');
  const [addedBanner, setAddedBanner] = useState(false);
  const [sizeGuideOpen, setSizeGuideOpen] = useState(false);

  // Local reviews state so user can submit a new review
  const [localReviews, setLocalReviews] = useState<ProductReview[]>(
    product.reviews
  );
  const [reviewName, setReviewName] = useState('');
  const [reviewCity, setReviewCity] = useState('');
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewComment, setReviewComment] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  // Sync when switching products
  React.useEffect(() => {
    setSelectedImageIdx(0);
    setSelectedSize(product.sizes.includes('M') ? 'M' : product.sizes[0] || 'M');
    setSelectedColor(product.colors[0]?.name || 'Default');
    setQuantity(1);
    setLocalReviews(product.reviews);
    setReviewSubmitted(false);
  }, [product]);

  const handlePincodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPincodeResult(checkPincodeDelivery(pincode));
  };

  const handleAddClick = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    setAddedBanner(true);
    setTimeout(() => setAddedBanner(false), 2200);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName.trim() || !reviewComment.trim()) return;
    const newRev: ProductReview = {
      id: `rev-${Date.now()}`,
      author: reviewName.trim(),
      location: reviewCity.trim() || 'India',
      rating: reviewRating,
      date: 'Just Now',
      title: reviewTitle.trim() || 'Verified Purchase Review',
      comment: reviewComment.trim(),
      verifiedSize: selectedSize,
    };
    setLocalReviews([newRev, ...localReviews]);
    setReviewName('');
    setReviewCity('');
    setReviewTitle('');
    setReviewComment('');
    setReviewSubmitted(true);
  };

  const relatedProducts = allProducts
    .filter((p) => p.id !== product.id)
    .slice(0, 5);

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
      {/* Breadcrumb & Back */}
      <div className="flex items-center justify-between mb-6">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#77706D] hover:text-[#701C35] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Collection</span>
        </button>
        <span className="text-xs text-[#77706D]">SKU: {product.sku}</span>
      </div>

      {/* Main Contiguous Product Module */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left: Multi-Image Gallery */}
        <div className="lg:col-span-6 flex flex-col-reverse sm:flex-row gap-4 lg:sticky lg:top-28">
          {/* Thumbnails */}
          <div className="flex sm:flex-col gap-3 overflow-x-auto sm:overflow-visible">
            {product.images.map((imgUrl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedImageIdx(idx)}
                aria-label={`View product image ${idx + 1}`}
                className={`w-18 h-24 sm:w-20 sm:h-28 rounded-xl overflow-hidden border-2 shrink-0 transition-all cursor-pointer bg-[#F2E8DF] ${
                  selectedImageIdx === idx
                    ? 'border-[#701C35] shadow-sm'
                    : 'border-transparent opacity-70 hover:opacity-100'
                }`}
              >
                <img
                  src={imgUrl}
                  alt={`${product.name} view ${idx + 1}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
              </button>
            ))}
          </div>

          {/* Primary Image */}
          <div className="flex-1 aspect-[3/4] rounded-2xl overflow-hidden bg-[#F2E8DF] border border-[#281A1D]/10 relative">
            <img
              src={product.images[selectedImageIdx] || product.images[0]}
              alt={product.name}
              referrerPolicy="no-referrer"
              style={{ objectPosition: product.imagePosition || 'center top' }}
              className={`w-full h-full object-cover ${product.imageScale || ''}`}
            />
            <button
              type="button"
              onClick={() => onToggleWishlist(product)}
              aria-label={
                isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'
              }
              className={`absolute top-4 right-4 w-11 h-11 rounded-full flex items-center justify-center shadow-md transition-all cursor-pointer ${
                isWishlisted
                  ? 'bg-[#701C35] text-white'
                  : 'bg-white/90 text-[#281A1D] hover:text-[#701C35]'
              }`}
            >
              <Heart
                className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`}
              />
            </button>
          </div>
        </div>

        {/* Right: Purchase & Details Column */}
        <div className="lg:col-span-6 space-y-6">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35] mb-1.5">
              Urban by Grace · {product.collection.toUpperCase()} ATELIER
            </p>
            <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
              {product.name}
            </h1>
            <p className="text-sm text-[#77706D] mt-1">{product.subtitle}</p>

            {/* Rating Summary */}
            <div className="flex items-center gap-2 mt-3 text-xs text-[#281A1D]">
              <div className="flex items-center gap-0.5 text-[#701C35]">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-semibold ml-1 tabular-nums">
                  {product.rating.toFixed(1)}
                </span>
              </div>
              <span aria-hidden="true">·</span>
              <span className="text-[#77706D] tabular-nums">
                {product.reviewCount +
                  (localReviews.length - product.reviews.length)}{' '}
                Verified Reviews
              </span>
            </div>
          </div>

          {/* Pricing Block */}
          <div className="p-4 rounded-xl bg-[#F2E8DF]/70 border border-[#281A1D]/10">
            <div className="flex items-baseline gap-3">
              <span className="text-2xl sm:text-3xl font-bold text-[#281A1D] tabular-nums">
                {formatINR(product.price)}
              </span>
              <span className="text-base text-[#77706D] line-through tabular-nums">
                MRP {formatINR(product.originalPrice)}
              </span>
              <span className="text-sm font-semibold text-[#701C35] tabular-nums">
                ({product.discountPercent}% OFF)
              </span>
            </div>
            <p className="text-xs text-[#77706D] mt-1">
              Inclusive of all taxes · Free shipping on orders above ₹999
            </p>
          </div>

          {/* Color Options */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#281A1D] mb-2.5">
              Color: <span className="font-normal text-[#77706D]">{selectedColor}</span>
            </p>
            <div className="flex items-center gap-3">
              {product.colors.map((c) => (
                <button
                  key={c.name}
                  type="button"
                  onClick={() => setSelectedColor(c.name)}
                  aria-label={`Select color ${c.name}`}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                    selectedColor === c.name
                      ? 'border-[#701C35] bg-[#FAF5F0] text-[#701C35] ring-1 ring-[#701C35]'
                      : 'border-[#281A1D]/15 bg-white text-[#281A1D] hover:border-[#701C35]/50'
                  }`}
                >
                  <span
                    className="w-4 h-4 rounded-full border border-black/20 shrink-0"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span>{c.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Size Selection (XS, S, M, L, XL, XXL) */}
          <div>
            <div className="flex items-center justify-between mb-2.5">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#281A1D]">
                Select Size:{' '}
                <span className="text-[#701C35]">{selectedSize}</span>
              </span>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(true)}
                className="inline-flex items-center gap-1 text-xs font-medium text-[#701C35] hover:underline cursor-pointer"
              >
                <Ruler className="w-3.5 h-3.5" />
                <span>Size Chart</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2.5">
              {ALL_SIZES.map((sz) => {
                const isAvailable = product.sizes.includes(sz);
                const isSelected = selectedSize === sz;
                return (
                  <button
                    key={sz}
                    type="button"
                    disabled={!isAvailable}
                    onClick={() => setSelectedSize(sz)}
                    aria-label={`Size ${sz}`}
                    className={`w-12 h-11 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#701C35] text-white shadow-xs'
                        : isAvailable
                        ? 'bg-white border border-[#281A1D]/20 text-[#281A1D] hover:border-[#701C35]'
                        : 'bg-[#F2E8DF]/50 border border-[#281A1D]/10 text-[#77706D]/40 line-through cursor-not-allowed'
                    }`}
                  >
                    {sz}
                  </button>
                );
              })}
            </div>
            <p className="text-xs text-[#77706D] mt-2">{product.fitNotes}</p>
          </div>

          {/* Quantity & Action Buttons */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center gap-4">
              <div className="flex items-center border border-[#281A1D]/20 rounded-xl bg-white">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  aria-label="Decrease quantity"
                  className="w-10 h-11 text-lg font-medium text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                >
                  −
                </button>
                <span
                  data-testid="pdp-quantity"
                  className="w-10 text-center text-sm font-semibold text-[#281A1D] tabular-nums"
                >
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                  aria-label="Increase quantity"
                  className="w-10 h-11 text-lg font-medium text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                >
                  +
                </button>
              </div>

              <button
                type="button"
                onClick={handleAddClick}
                className="flex-1 py-3.5 px-6 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart — {formatINR(product.price * quantity)}</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() =>
                onBuyNow(product, selectedSize, selectedColor, quantity)
              }
              className="w-full py-3.5 px-6 rounded-xl bg-[#281A1D] hover:bg-[#3D101D] text-white font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
            >
              <Zap className="w-4 h-4 text-[#E8C5CA]" />
              <span>Buy Now (Express Checkout)</span>
            </button>

            {addedBanner && (
              <div
                role="status"
                className="flex items-center gap-2 p-3 rounded-xl bg-[#701C35]/10 border border-[#701C35]/30 text-xs font-medium text-[#701C35]"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  Added {quantity} × {product.name} (Size {selectedSize}) to your
                  shopping bag!
                </span>
              </div>
            )}
          </div>

          {/* Delivery Pincode Checker */}
          <div className="p-4 rounded-xl bg-white border border-[#281A1D]/12 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#281A1D]">
              <MapPin className="w-4 h-4 text-[#701C35]" />
              <span>Check Delivery &amp; COD Availability</span>
            </div>

            <form onSubmit={handlePincodeSubmit} className="flex gap-2">
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={pincode}
                onChange={(e) => setPincode(e.target.value)}
                placeholder="Enter 6-digit Pincode (e.g. 400001)"
                aria-label="Enter delivery pincode"
                className="flex-1 px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm text-[#281A1D] focus:outline-none focus:border-[#701C35] tabular-nums"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-[#F2E8DF] hover:bg-[#701C35] text-[#281A1D] hover:text-white text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                Check
              </button>
            </form>

            {pincodeResult && (
              <div className="text-xs pt-1">
                {pincodeResult.valid ? (
                  <div className="space-y-1 text-[#281A1D]">
                    <p className="font-semibold text-[#701C35] flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>
                        {pincodeResult.deliveryDateLabel} to{' '}
                        {pincodeResult.city}, {pincodeResult.state} (
                        {pincodeResult.pincode})
                      </span>
                    </p>
                    <p className="text-[#77706D]">
                      Cash on Delivery (COD) Available · Free Shipping above ₹999
                    </p>
                  </div>
                ) : (
                  <p className="text-red-700 font-medium">
                    {pincodeResult.error}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Description / Fabric Details / Return Policy Tabs */}
          <div className="border-t border-[#281A1D]/10 pt-5">
            <div className="flex gap-2 border-b border-[#281A1D]/10 pb-3">
              {[
                { id: 'description', label: 'Product Description' },
                { id: 'fabric', label: 'Fabric & Care' },
                { id: 'returns', label: 'Shipping & Returns' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => setActiveTab(t.id as any)}
                  className={`px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === t.id
                      ? 'bg-[#701C35] text-white'
                      : 'bg-[#F2E8DF]/60 text-[#281A1D] hover:bg-[#F2E8DF]'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="py-4 text-sm text-[#281A1D]/90 leading-relaxed">
              {activeTab === 'description' && <p>{product.description}</p>}

              {activeTab === 'fabric' && (
                <div className="space-y-3">
                  <ul className="list-disc pl-5 space-y-1.5">
                    {product.fabricDetails.map((fd, i) => (
                      <li key={i}>{fd}</li>
                    ))}
                  </ul>
                  <p className="text-xs text-[#77706D] pt-1">
                    <strong>Care Instructions:</strong>{' '}
                    {product.careInstructions}
                  </p>
                </div>
              )}

              {activeTab === 'returns' && (
                <div className="space-y-2 text-xs sm:text-sm">
                  <p className="flex items-center gap-2 font-medium text-[#281A1D]">
                    <Truck className="w-4 h-4 text-[#701C35]" />
                    <span>
                      Free insured shipping across India on all orders above
                      ₹999. Dispatched within 24–48 hours.
                    </span>
                  </p>
                  <p className="flex items-center gap-2 font-medium text-[#281A1D]">
                    <RotateCcw className="w-4 h-4 text-[#701C35]" />
                    <span>
                      Easy 7-Day Returns &amp; Size Exchanges. Doorstep reverse
                      pickup at zero extra cost.
                    </span>
                  </p>
                  <p className="flex items-center gap-2 font-medium text-[#281A1D]">
                    <ShieldCheck className="w-4 h-4 text-[#701C35]" />
                    <span>
                      100% Authentic Urban by Grace quality guarantee.
                    </span>
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Customer Reviews Section */}
      <section className="mt-16 pt-10 border-t border-[#281A1D]/10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-5 space-y-4">
            <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold text-[#281A1D]">
              Customer Reviews
            </h2>
            <p className="text-sm text-[#77706D]">
              Real feedback from patrons across India wearing {product.name}.
            </p>

            {/* Write a Review Form */}
            <form
              onSubmit={handleReviewSubmit}
              className="p-5 rounded-2xl bg-white border border-[#281A1D]/10 space-y-3"
            >
              <h3 className="text-sm font-semibold text-[#281A1D]">
                Share Your Experience
              </h3>
              <div className="grid grid-cols-2 gap-2.5">
                <input
                  type="text"
                  value={reviewName}
                  onChange={(e) => setReviewName(e.target.value)}
                  placeholder="Your Name *"
                  aria-label="Reviewer Name"
                  required
                  className="px-3 py-2 rounded-lg border border-[#281A1D]/20 text-xs focus:outline-none focus:border-[#701C35]"
                />
                <input
                  type="text"
                  value={reviewCity}
                  onChange={(e) => setReviewCity(e.target.value)}
                  placeholder="City (e.g. Mumbai)"
                  aria-label="Reviewer City"
                  className="px-3 py-2 rounded-lg border border-[#281A1D]/20 text-xs focus:outline-none focus:border-[#701C35]"
                />
              </div>

              <div className="flex items-center gap-3 text-xs">
                <span className="text-[#77706D]">Rating:</span>
                {[5, 4, 3].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setReviewRating(r)}
                    className={`px-2.5 py-1 rounded-md font-medium cursor-pointer ${
                      reviewRating === r
                        ? 'bg-[#701C35] text-white'
                        : 'bg-[#F2E8DF] text-[#281A1D]'
                    }`}
                  >
                    {r} ★
                  </button>
                ))}
              </div>

              <input
                type="text"
                value={reviewTitle}
                onChange={(e) => setReviewTitle(e.target.value)}
                placeholder="Review Headline"
                aria-label="Review Headline"
                className="w-full px-3 py-2 rounded-lg border border-[#281A1D]/20 text-xs focus:outline-none focus:border-[#701C35]"
              />
              <textarea
                rows={3}
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                placeholder="How was the fabric, embroidery, and fit? *"
                aria-label="Review Comment"
                required
                className="w-full px-3 py-2 rounded-lg border border-[#281A1D]/20 text-xs focus:outline-none focus:border-[#701C35]"
              />
              <button
                type="submit"
                className="px-5 py-2.5 rounded-lg bg-[#701C35] hover:bg-[#3D101D] text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                Submit Review
              </button>
              {reviewSubmitted && (
                <p className="text-xs text-[#701C35] font-medium">
                  Thank you! Your review has been published.
                </p>
              )}
            </form>
          </div>

          <div className="lg:col-span-7 space-y-4">
            {localReviews.length === 0 ? (
              <div className="p-8 rounded-2xl bg-white border border-[#281A1D]/10 text-center">
                <p className="text-sm text-[#77706D]">
                  Be the first to review {product.name}!
                </p>
              </div>
            ) : (
              localReviews.map((rev) => (
                <div
                  key={rev.id}
                  className="p-5 rounded-2xl bg-white border border-[#281A1D]/10 space-y-2"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-[#701C35] font-semibold">
                      <span>{'★'.repeat(rev.rating)}</span>
                      <span className="text-[#281A1D]">{rev.title}</span>
                    </div>
                    <span className="text-xs text-[#77706D]">{rev.date}</span>
                  </div>
                  <p className="text-sm text-[#281A1D]/90">{rev.comment}</p>
                  <p className="text-xs text-[#77706D]">
                    {rev.author} · {rev.location} · Verified Buyer (Size{' '}
                    {rev.verifiedSize})
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* You May Also Like */}
      <section className="mt-16 pt-10 border-t border-[#281A1D]/10">
        <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold text-[#281A1D] text-center mb-8">
          You May Also Like
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6">
          {relatedProducts.map((rp) => (
            <ProductCard
              key={rp.id}
              product={rp}
              isWishlisted={wishlistIds.includes(rp.id)}
              onToggleWishlist={onToggleWishlist}
              onQuickAddToCart={(p) =>
                onAddToCart(p, p.sizes[0] || 'M', p.colors[0]?.name || 'Default', 1)
              }
              onSelectProduct={onSelectProduct}
              onQuickView={onQuickView}
            />
          ))}
        </div>
      </section>

      {/* Size Chart Modal */}
      {sizeGuideOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Urban by Grace Size Chart"
          className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
        >
          <div className="bg-[#FAF5F0] rounded-2xl max-w-lg w-full p-6 border border-[#281A1D]/15 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-serif-display text-2xl font-semibold text-[#281A1D]">
                Urban by Grace Size Guide (Inches)
              </h3>
              <button
                type="button"
                onClick={() => setSizeGuideOpen(false)}
                aria-label="Close size chart"
                className="p-1.5 rounded-lg text-[#77706D] hover:text-[#281A1D]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs sm:text-sm text-left border-collapse tabular-nums">
                <thead>
                  <tr className="border-b border-[#281A1D]/15 text-[#701C35]">
                    <th className="py-2">Size</th>
                    <th className="py-2">Bust / Chest</th>
                    <th className="py-2">Waist</th>
                    <th className="py-2">Hip</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#281A1D]/10">
                  {[
                    { s: 'XS', b: '32"', w: '26"', h: '35"' },
                    { s: 'S', b: '34"', w: '28"', h: '37"' },
                    { s: 'M', b: '36"', w: '30"', h: '39"' },
                    { s: 'L', b: '38"', w: '32"', h: '41"' },
                    { s: 'XL', b: '40"', w: '34"', h: '43"' },
                    { s: 'XXL', b: '42"', w: '36"', h: '45"' },
                  ].map((r) => (
                    <tr key={r.s}>
                      <td className="py-2 font-semibold">{r.s}</td>
                      <td className="py-2">{r.b}</td>
                      <td className="py-2">{r.w}</td>
                      <td className="py-2">{r.h}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
