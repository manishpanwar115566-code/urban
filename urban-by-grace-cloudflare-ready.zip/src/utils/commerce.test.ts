import test from 'node:test';
import assert from 'node:assert/strict';
import {
  formatINR,
  calculateDiscountPercent,
  calculateCartSummary,
  checkPincodeDelivery,
  validateCouponCode,
  validateCheckoutForm,
} from './commerce';
import { CartItem, Product } from '../types/store';

const sampleProduct: Product = {
  id: 'prod-1',
  name: 'Embroidered Kurta Set',
  subtitle: 'Burgundy Zardozi Silk Kurta with Organza Dupatta',
  price: 1899,
  originalPrice: 2499,
  discountPercent: 24,
  category: 'kurtas-suits',
  gender: 'women',
  collection: 'ethnic',
  isNewArrival: true,
  isOnSale: true,
  images: ['/test.jpg'],
  sizes: ['S', 'M', 'L'],
  colors: [{ name: 'Burgundy', hex: '#701C35' }],
  description: 'Handcrafted silk blend kurta set.',
  fabricDetails: ['Silk Chanderi'],
  careInstructions: 'Dry clean only',
  fitNotes: 'Regular fit',
  rating: 4.9,
  reviewCount: 42,
  reviews: [],
  sku: 'UBG-KS-01',
};

test('formatINR formats Indian currency accurately', () => {
  assert.equal(formatINR(999), '₹999');
  assert.equal(formatINR(1899), '₹1,899');
  assert.equal(formatINR(125000), '₹1,25,000');
});

test('calculateDiscountPercent computes accurate percentage off', () => {
  assert.equal(calculateDiscountPercent(1899, 2499), 24);
  assert.equal(calculateDiscountPercent(1299, 1699), 24);
  assert.equal(calculateDiscountPercent(999, 1299), 23);
});

test('calculateCartSummary handles free shipping above ₹999 and coupon discounts', () => {
  const items: CartItem[] = [
    { product: sampleProduct, size: 'M', color: 'Burgundy', quantity: 2 },
  ];

  const summaryNoCoupon = calculateCartSummary(items, null);
  assert.equal(summaryNoCoupon.itemCount, 2);
  assert.equal(summaryNoCoupon.mrpTotal, 4998);
  assert.equal(summaryNoCoupon.subtotal, 3798);
  assert.equal(summaryNoCoupon.productDiscount, 1200);
  assert.equal(summaryNoCoupon.shippingFee, 0);
  assert.equal(summaryNoCoupon.payableAmount, 3798);

  const summaryWithGrace10 = calculateCartSummary(items, 'grace10');
  assert.equal(summaryWithGrace10.couponCode, 'GRACE10');
  assert.equal(summaryWithGrace10.couponDiscount, 380);
  assert.equal(summaryWithGrace10.payableAmount, 3418);
});

test('checkPincodeDelivery validates 6-digit Indian pincodes', () => {
  const validMumbai = checkPincodeDelivery('400001');
  assert.equal(validMumbai.valid, true);
  assert.equal(validMumbai.city, 'Mumbai');
  assert.equal(validMumbai.codAvailable, true);

  const invalidCode = checkPincodeDelivery('01234');
  assert.equal(invalidCode.valid, false);
  assert.ok(invalidCode.error);
});

test('validateCouponCode enforces minimum subtotal thresholds', () => {
  const resLow = validateCouponCode('URBAN15', 1500);
  assert.equal(resLow.valid, false);

  const resValid = validateCouponCode('GRACE10', 1899);
  assert.equal(resValid.valid, true);
  assert.equal(resValid.code, 'GRACE10');
});

test('validateCheckoutForm rejects empty or invalid inputs and accepts valid Indian details', () => {
  const bad = validateCheckoutForm({
    fullName: '',
    email: 'invalid-email',
    phone: '12345',
    addressLine1: 'ab',
    city: '',
    state: '',
    pincode: '12',
    paymentMethod: 'upi',
    upiId: 'invalidupi',
  });
  assert.equal(bad.valid, false);
  assert.ok(bad.errors.fullName);
  assert.ok(bad.errors.phone);
  assert.ok(bad.errors.pincode);
  assert.ok(bad.errors.upiId);

  const good = validateCheckoutForm({
    fullName: 'Ananya Sharma',
    email: 'ananya@example.com',
    phone: '9876543210',
    addressLine1: '42 Heritage Enclave, MG Road',
    city: 'Mumbai',
    state: 'Maharashtra',
    pincode: '400001',
    paymentMethod: 'cod',
  });
  assert.equal(good.valid, true);
  assert.equal(Object.keys(good.errors).length, 0);
});
