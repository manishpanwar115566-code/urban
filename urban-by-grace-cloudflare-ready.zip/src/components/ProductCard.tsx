import React, { useState } from 'react';
import { Heart, ShoppingBag, Check, Eye } from 'lucide-react';
import { Product } from '../types/store';
import { formatINR } from '../utils/commerce';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onQuickAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickView?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onQuickAddToCart,
  onSelectProduct,
  onQuickView,
}) => {
  const [imgError, setImgError] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAddToCart(product);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1400);
  };

  return (
    <article className="group flex flex-col bg-white rounded-2xl border border-[#281A1D]/8 overflow-hidden shadow-xs hover:shadow-md transition-all duration-200">
      {/* Vertical Product Image Container */}
      <div className="relative aspect-[3/4] w-full bg-[#F2E8DF] overflow-hidden">
        <button
          type="button"
          onClick={() => onSelectProduct(product)}
          aria-label={`View details for ${product.name}`}
          className="w-full h-full block text-left focus:outline-none cursor-pointer"
        >
          {!imgError ? (
            <img
              src={product.images[0]}
              alt={product.name}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              style={{ objectPosition: product.imagePosition || 'center top' }}
              className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 ${
                product.imageScale || ''
              }`}
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-b from-[#F2E8DF] to-[#E8C5CA]/40 text-center">
              <span className="font-serif-display text-lg text-[#701C35]">
                Urban by Grace
              </span>
              <span className="text-xs text-[#281A1D] mt-1">{product.name}</span>
            </div>
          )}
        </button>

        {/* Top-Right Action Icons: Wishlist Heart & Dedicated Quick-View Button */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 z-10">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleWishlist(product);
            }}
            aria-label={
              isWishlisted
                ? `Remove ${product.name} from wishlist`
                : `Add ${product.name} to wishlist`
            }
            className={`w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 shadow-xs cursor-pointer ${
              isWishlisted
                ? 'bg-[#701C35] text-white scale-105'
                : 'bg-white/90 hover:bg-white text-[#281A1D] hover:text-[#701C35]'
            }`}
          >
            <Heart
              className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`}
            />
          </button>

          {onQuickView && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onQuickView(product);
              }}
              aria-label={`Quick view ${product.name}`}
              title="Quick View"
              className="w-9 h-9 rounded-full bg-white/90 hover:bg-[#701C35] text-[#281A1D] hover:text-white flex items-center justify-center transition-all duration-200 shadow-xs cursor-pointer"
            >
              <Eye className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Quick Add to Cart Button on Hover / Mobile Accessible */}
        <div className="absolute inset-x-3 bottom-3 opacity-95 sm:opacity-0 sm:translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200">
          <button
            type="button"
            onClick={handleQuickAdd}
            aria-label={`Add ${product.name} to cart`}
            className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md transition-colors cursor-pointer whitespace-nowrap ${
              justAdded
                ? 'bg-[#281A1D] text-white'
                : 'bg-[#FAF5F0]/95 hover:bg-[#701C35] text-[#281A1D] hover:text-white border border-[#281A1D]/10'
            }`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Added to Bag</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Cart</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Product Metadata Below Image */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          <button
            type="button"
            onClick={() => onSelectProduct(product)}
            className="text-left block w-full focus:outline-none group/title cursor-pointer"
          >
            <h3 className="text-sm sm:text-[15px] font-medium text-[#281A1D] group-hover/title:text-[#701C35] transition-colors truncate">
              {product.name}
            </h3>
          </button>
          <p className="text-xs text-[#77706D] truncate mt-0.5">
            {product.subtitle}
          </p>
        </div>

        <div className="mt-2.5 flex items-baseline flex-wrap gap-x-2 gap-y-0.5">
          <span className="text-sm sm:text-base font-bold text-[#281A1D] tabular-nums">
            {formatINR(product.price)}
          </span>
          <span className="text-xs text-[#77706D] line-through tabular-nums">
            {formatINR(product.originalPrice)}
          </span>
          <span className="text-xs font-semibold text-[#701C35] tabular-nums">
            ({product.discountPercent}% OFF)
          </span>
        </div>
      </div>
    </article>
  );
};
