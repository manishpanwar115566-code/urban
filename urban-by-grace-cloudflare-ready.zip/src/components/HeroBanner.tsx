import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { HERO_SLIDES } from '../data/catalog';
import { PageId } from '../types/store';

interface HeroBannerProps {
  onNavigate: (page: PageId) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onNavigate }) => {
  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 6500);
    return () => clearInterval(timer);
  }, []);

  const slide = HERO_SLIDES[activeSlide];

  return (
    <section
      aria-label="Featured Collection Hero Banner"
      className="relative overflow-hidden bg-[#F2E8DF] border-b border-[#281A1D]/10"
    >
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10">
        <div className="relative rounded-2xl overflow-hidden bg-[#F4EAE0] border border-[#701C35]/15 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[440px] sm:min-h-[500px] lg:min-h-[540px]">
            {/* Left Side: Luxury Editorial Copy */}
            <div className="lg:col-span-5 flex flex-col justify-center px-6 sm:px-10 lg:px-12 py-10 lg:py-12 z-10 bg-[#F4EAE0]">
              <p className="text-xs sm:text-[13px] tracking-[0.22em] font-semibold text-[#701C35] uppercase mb-3">
                {slide.kicker}
              </p>

              <h1 className="font-serif-display text-4xl sm:text-5xl lg:text-[54px] font-semibold text-[#281A1D] leading-[1.1] tracking-tight mb-4">
                <span className="block">{slide.titleLine1}</span>
                <span className="block italic font-normal text-[#701C35] mt-1">
                  {slide.titleLine2}
                </span>
              </h1>

              <p className="text-sm sm:text-base font-medium text-[#77706D] tracking-wide mb-7">
                {slide.subheading}
              </p>

              <div>
                <button
                  type="button"
                  onClick={() => onNavigate(slide.targetPage)}
                  className="inline-flex items-center gap-2.5 bg-[#701C35] hover:bg-[#3D101D] text-white text-sm sm:text-base font-medium px-7 py-3.5 rounded-full shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer group"
                >
                  <span>{slide.ctaLabel}</span>
                  <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
                </button>
              </div>

              <p className="mt-6 text-xs text-[#77706D]">
                {slide.badgeText}
              </p>
            </div>

            {/* Right Side: Premium Fashion Model Photography in Warm Beige Architectural Setting */}
            <div className="lg:col-span-7 relative min-h-[300px] sm:min-h-[380px] lg:min-h-full overflow-hidden bg-[#F4EAE0]">
              <img
                key={slide.id}
                src={slide.image}
                alt={`${slide.titleLine1} ${slide.titleLine2}`}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-top transition-transform duration-700"
              />
              {/* Soft editorial gradient blend on desktop between left copy and right photo */}
              <div className="hidden lg:block absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#F4EAE0] via-[#F4EAE0]/70 to-transparent pointer-events-none" />
            </div>
          </div>

          {/* Carousel Controls & Dots */}
          <div className="absolute bottom-4 left-6 sm:left-10 lg:left-12 right-6 flex items-center justify-between pointer-events-none z-20">
            <div className="flex items-center gap-2 pointer-events-auto bg-[#FAF5F0]/85 backdrop-blur-sm px-3 py-1.5 rounded-full border border-[#281A1D]/10">
              {HERO_SLIDES.map((s, idx) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setActiveSlide(idx)}
                  aria-label={`Go to slide ${idx + 1}: ${s.titleLine1}`}
                  className={`h-2 rounded-full transition-all ${
                    activeSlide === idx
                      ? 'w-7 bg-[#701C35]'
                      : 'w-2 bg-[#701C35]/30 hover:bg-[#701C35]/60'
                  }`}
                />
              ))}
            </div>

            <div className="hidden sm:flex items-center gap-2 pointer-events-auto">
              <button
                type="button"
                onClick={() =>
                  setActiveSlide(
                    (prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length
                  )
                }
                aria-label="Previous hero slide"
                className="w-9 h-9 rounded-full bg-[#FAF5F0]/90 hover:bg-[#701C35] text-[#281A1D] hover:text-white flex items-center justify-center border border-[#281A1D]/10 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() =>
                  setActiveSlide((prev) => (prev + 1) % HERO_SLIDES.length)
                }
                aria-label="Next hero slide"
                className="w-9 h-9 rounded-full bg-[#FAF5F0]/90 hover:bg-[#701C35] text-[#281A1D] hover:text-white flex items-center justify-center border border-[#281A1D]/10 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
