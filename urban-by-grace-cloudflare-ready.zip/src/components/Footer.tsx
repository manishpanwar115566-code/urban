import React, { useState } from 'react';
import {
  Instagram,
  Facebook,
  Share2,
  Send,
  CheckCircle2,
  ShieldCheck,
} from 'lucide-react';
import { PageId } from '../types/store';

interface FooterProps {
  onNavigate: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="bg-[#281A1D] text-[#FAF5F0] border-t border-[#701C35]/30 mt-16">
      {/* Newsletter Banner */}
      <div className="border-b border-white/10">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-10 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="text-center lg:text-left">
            <p className="text-xs uppercase tracking-[0.2em] text-[#E8C5CA] font-semibold">
              THE GRACE JOURNAL
            </p>
            <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold text-white mt-1">
              Subscribe for Private Atelier Previews &amp; 10% Off
            </h2>
          </div>

          <form
            onSubmit={handleSubscribe}
            className="w-full max-w-md flex items-center gap-2"
          >
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address..."
              aria-label="Newsletter email address"
              className="flex-1 px-4 py-3 rounded-xl bg-white/10 border border-white/20 text-sm text-white placeholder:text-white/60 focus:outline-none focus:border-[#E8C5CA]"
            />
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-[#701C35] hover:bg-[#E8C5CA] text-white hover:text-[#281A1D] text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
            >
              <span>Subscribe</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

          {subscribed && (
            <p className="text-xs text-[#E8C5CA] flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" />
              <span>Welcome to Urban by Grace! Use code GRACE10 at checkout.</span>
            </p>
          )}
        </div>
      </div>

      {/* 4-Column Main Footer */}
      <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Brand & Tagline */}
          <div className="space-y-4">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="text-left focus:outline-none cursor-pointer"
            >
              <span className="font-serif-display text-2xl sm:text-3xl font-semibold text-white">
                Urban <span className="italic font-normal text-[#E8C5CA]">by</span> Grace
              </span>
            </button>
            <p className="font-editorial italic text-lg text-[#E8C5CA]">
              Style That Speaks. Grace That Lasts.
            </p>
            <p className="text-xs text-white/70 leading-relaxed">
              Luxury Indian ethnic wear and contemporary western fashion
              crafted for the modern wardrobe across India.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#E8C5CA] mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  Contact Us
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('new-arrivals')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  New Arrivals
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Customer Support */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#E8C5CA] mb-4">
              Customer Support
            </h3>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('shipping-policy')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  Shipping Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('return-policy')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  Return &amp; Refund
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('privacy-policy')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onNavigate('contact')}
                  className="hover:text-[#E8C5CA] transition-colors cursor-pointer"
                >
                  FAQs &amp; Sizing Help
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Follow Us */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#E8C5CA] mb-4">
              Follow Us
            </h3>
            <div className="flex flex-col space-y-2.5 text-sm text-white/80">
              <a
                href="#instagram"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('new-arrivals');
                }}
                className="inline-flex items-center gap-2.5 hover:text-[#E8C5CA] transition-colors"
              >
                <Instagram className="w-4 h-4 text-[#E8C5CA]" />
                <span>Instagram (@urbanbygrace)</span>
              </a>
              <a
                href="#facebook"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('ethnic-wear');
                }}
                className="inline-flex items-center gap-2.5 hover:text-[#E8C5CA] transition-colors"
              >
                <Facebook className="w-4 h-4 text-[#E8C5CA]" />
                <span>Facebook</span>
              </a>
              <a
                href="#pinterest"
                onClick={(e) => {
                  e.preventDefault();
                  onNavigate('western-wear');
                }}
                className="inline-flex items-center gap-2.5 hover:text-[#E8C5CA] transition-colors"
              >
                <Share2 className="w-4 h-4 text-[#E8C5CA]" />
                <span>Pinterest Lookbooks</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Payment & Copyright Strip */}
      <div className="bg-[#1E1315] border-t border-white/10 py-5 px-4 sm:px-6 lg:px-8">
        <div className="max-w-[1360px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-white/60">
          <p>
            © {new Date().getFullYear()} Urban by Grace. All rights reserved.
            Designed for India (INR ₹).
          </p>

          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 text-white/80 mr-1">
              <ShieldCheck className="w-3.5 h-3.5 text-[#E8C5CA]" />
              <span>100% Secure:</span>
            </span>
            {['UPI', 'RuPay', 'Visa', 'Mastercard', 'NetBanking', 'COD'].map(
              (pm) => (
                <span
                  key={pm}
                  className="px-2.5 py-1 rounded bg-white/10 text-white/90 text-[11px] font-medium"
                >
                  {pm}
                </span>
              )
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
