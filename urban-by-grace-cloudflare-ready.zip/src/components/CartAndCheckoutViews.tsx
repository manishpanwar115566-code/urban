import React, { useState } from 'react';
import {
  X,
  Trash2,
  ShoppingBag,
  ArrowRight,
  Tag,
  CheckCircle2,
  ShieldCheck,
  Truck,
  CreditCard,
  Smartphone,
  Banknote,
  Building2,
} from 'lucide-react';
import {
  CartItem,
  CartSummary,
  CheckoutInput,
  OrderRecord,
  PageId,
  Product,
  SizeOption,
} from '../types/store';
import {
  formatINR,
  validateCheckoutForm,
  validateCouponCode,
  VALID_COUPONS,
} from '../utils/commerce';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  summary: CartSummary;
  onUpdateQty: (
    productId: string,
    size: SizeOption,
    color: string,
    delta: number
  ) => void;
  onRemoveItem: (productId: string, size: SizeOption, color: string) => void;
  onGoToCart: () => void;
  onGoToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  summary,
  onUpdateQty,
  onRemoveItem,
  onGoToCart,
  onGoToCheckout,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Shopping Bag Drawer"
      className="fixed inset-0 z-50 bg-black/50 flex justify-end"
    >
      <div className="bg-[#FAF5F0] w-full max-w-md h-full flex flex-col shadow-2xl border-l border-[#281A1D]/10">
        {/* Header */}
        <div className="px-6 py-4 bg-white border-b border-[#281A1D]/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#701C35]" />
            <h2 className="font-serif-display text-xl font-semibold text-[#281A1D]">
              Your Shopping Bag ({summary.itemCount})
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shopping bag"
            className="p-2 text-[#77706D] hover:text-[#281A1D] rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Bar */}
        <div className="bg-[#F2E8DF] px-6 py-2.5 text-xs text-[#281A1D] border-b border-[#281A1D]/10">
          {summary.freeShippingRemaining === 0 ? (
            <p className="font-medium text-[#701C35] flex items-center gap-1.5">
              <Truck className="w-4 h-4 shrink-0" />
              <span>Congratulations! You unlocked FREE Express Shipping.</span>
            </p>
          ) : (
            <p>
              Add{' '}
              <strong className="text-[#701C35] tabular-nums">
                {formatINR(summary.freeShippingRemaining)}
              </strong>{' '}
              more to unlock Free Shipping!
            </p>
          )}
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {items.length === 0 ? (
            <div className="text-center py-16 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#F2E8DF] text-[#701C35] flex items-center justify-center mx-auto">
                <ShoppingBag className="w-7 h-7" />
              </div>
              <p className="font-serif-display text-2xl text-[#281A1D]">
                Your bag is currently empty
              </p>
              <p className="text-xs text-[#77706D] max-w-xs mx-auto">
                Explore our New Season Kurtas, Floral Midi Dresses, and Western
                Co-ord Sets.
              </p>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={`${item.product.id}-${item.size}-${item.color}`}
                className="flex gap-3.5 p-3 rounded-xl bg-white border border-[#281A1D]/10"
              >
                <img
                  src={item.product.images[0]}
                  alt={item.product.name}
                  referrerPolicy="no-referrer"
                  className="w-20 h-26 object-cover object-top rounded-lg bg-[#F2E8DF] shrink-0"
                />
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-medium text-[#281A1D] truncate">
                        {item.product.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() =>
                          onRemoveItem(item.product.id, item.size, item.color)
                        }
                        aria-label={`Remove ${item.product.name}`}
                        className="text-[#77706D] hover:text-red-700 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-[#77706D] mt-0.5">
                      Size: {item.size} · {item.color}
                    </p>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <div className="flex items-center border border-[#281A1D]/20 rounded-lg">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.product.id, item.size, item.color, -1)
                        }
                        aria-label={`Decrease quantity of ${item.product.name}`}
                        className="w-7 h-7 text-xs font-semibold text-[#281A1D] hover:bg-[#F2E8DF] cursor-pointer"
                      >
                        −
                      </button>
                      <span className="w-7 text-center text-xs font-semibold tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.product.id, item.size, item.color, 1)
                        }
                        aria-label={`Increase quantity of ${item.product.name}`}
                        className="w-7 h-7 text-xs font-semibold text-[#281A1D] hover:bg-[#F2E8DF] cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-sm font-bold text-[#281A1D] tabular-nums">
                        {formatINR(item.product.price * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Actions */}
        {items.length > 0 && (
          <div className="p-6 bg-white border-t border-[#281A1D]/10 space-y-4">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-[#77706D]">
                <span>Bag MRP ({summary.itemCount} items)</span>
                <span className="tabular-nums">
                  {formatINR(summary.mrpTotal)}
                </span>
              </div>
              <div className="flex justify-between text-[#701C35]">
                <span>Product Discount</span>
                <span className="tabular-nums">
                  −{formatINR(summary.productDiscount)}
                </span>
              </div>
              {summary.couponDiscount > 0 && (
                <div className="flex justify-between text-[#701C35] font-medium">
                  <span>Coupon ({summary.couponCode})</span>
                  <span className="tabular-nums">
                    −{formatINR(summary.couponDiscount)}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-[#281A1D] pt-2 border-t border-[#281A1D]/10">
                <span>Payable Amount</span>
                <span className="tabular-nums">
                  {formatINR(summary.payableAmount)}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGoToCart();
                }}
                className="py-3 px-4 rounded-xl border border-[#701C35] text-[#701C35] hover:bg-[#FAF5F0] text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                View Full Bag
              </button>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGoToCheckout();
                }}
                className="py-3 px-4 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
              >
                <span>Checkout</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/* ============================================================================
   FULL SHOPPING CART PAGE
   ============================================================================ */
interface CartPageViewProps {
  items: CartItem[];
  summary: CartSummary;
  appliedCoupon: string | null;
  onApplyCoupon: (code: string | null) => void;
  onUpdateQty: (
    productId: string,
    size: SizeOption,
    color: string,
    delta: number
  ) => void;
  onRemoveItem: (productId: string, size: SizeOption, color: string) => void;
  onNavigate: (page: PageId) => void;
  onSelectProduct: (product: Product) => void;
}

export const CartPageView: React.FC<CartPageViewProps> = ({
  items,
  summary,
  appliedCoupon,
  onApplyCoupon,
  onUpdateQty,
  onRemoveItem,
  onNavigate,
  onSelectProduct,
}) => {
  const [couponInput, setCouponInput] = useState(appliedCoupon || '');
  const [couponMsg, setCouponMsg] = useState<{
    valid: boolean;
    text: string;
  } | null>(null);

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = validateCouponCode(couponInput, summary.subtotal);
    setCouponMsg({ valid: res.valid, text: res.message });
    if (res.valid && res.code) {
      onApplyCoupon(res.code);
    }
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D] mb-8">
        Shopping Bag ({summary.itemCount}{' '}
        {summary.itemCount === 1 ? 'Item' : 'Items'})
      </h1>

      {items.length === 0 ? (
        <div className="bg-white rounded-2xl border border-[#281A1D]/10 p-12 text-center max-w-xl mx-auto space-y-4">
          <ShoppingBag className="w-12 h-12 text-[#701C35] mx-auto" />
          <h2 className="font-serif-display text-2xl text-[#281A1D]">
            Your Shopping Bag is Empty
          </h2>
          <p className="text-sm text-[#77706D]">
            Discover our latest embroidered ethnic wear, floral dresses, and
            tailored western co-ord sets.
          </p>
          <button
            type="button"
            onClick={() => onNavigate('new-arrivals')}
            className="inline-flex items-center gap-2 bg-[#701C35] hover:bg-[#3D101D] text-white text-sm font-medium px-6 py-3 rounded-full transition-colors cursor-pointer"
          >
            <span>Shop New Arrivals</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Cart Items */}
          <div className="lg:col-span-8 space-y-4">
            {items.map((item) => (
              <div
                key={`${item.product.id}-${item.size}-${item.color}`}
                className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-4 sm:p-5 rounded-2xl bg-white border border-[#281A1D]/10"
              >
                <button
                  type="button"
                  onClick={() => onSelectProduct(item.product)}
                  className="w-24 h-32 rounded-xl overflow-hidden bg-[#F2E8DF] shrink-0 cursor-pointer"
                >
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-top"
                  />
                </button>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <button
                        type="button"
                        onClick={() => onSelectProduct(item.product)}
                        className="text-base font-semibold text-[#281A1D] hover:text-[#701C35] text-left cursor-pointer"
                      >
                        {item.product.name}
                      </button>
                      <p className="text-xs text-[#77706D] mt-0.5">
                        {item.product.subtitle}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        onRemoveItem(item.product.id, item.size, item.color)
                      }
                      aria-label={`Remove ${item.product.name} from cart`}
                      className="text-xs text-[#77706D] hover:text-red-700 flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                      <span className="hidden sm:inline">Remove</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-[#281A1D]">
                    <span className="px-2.5 py-1 rounded-md bg-[#FAF5F0] border border-[#281A1D]/10 font-medium">
                      Size: {item.size}
                    </span>
                    <span className="px-2.5 py-1 rounded-md bg-[#FAF5F0] border border-[#281A1D]/10 font-medium">
                      Color: {item.color}
                    </span>
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-[#281A1D]/8">
                    <div className="flex items-center border border-[#281A1D]/20 rounded-xl bg-[#FAF5F0]">
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.product.id, item.size, item.color, -1)
                        }
                        aria-label={`Decrease quantity of ${item.product.name}`}
                        className="w-9 h-9 text-sm font-semibold text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                      >
                        −
                      </button>
                      <span
                        data-testid={`cart-qty-${item.product.id}`}
                        className="w-9 text-center text-sm font-semibold tabular-nums"
                      >
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateQty(item.product.id, item.size, item.color, 1)
                        }
                        aria-label={`Increase quantity of ${item.product.name}`}
                        className="w-9 h-9 text-sm font-semibold text-[#281A1D] hover:text-[#701C35] cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-bold text-[#281A1D] tabular-nums">
                        {formatINR(item.product.price * item.quantity)}
                      </span>
                      <span className="text-xs text-[#77706D] line-through ml-2 tabular-nums">
                        {formatINR(item.product.originalPrice * item.quantity)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right: Coupon & Price Breakdown */}
          <div className="lg:col-span-4 space-y-5 lg:sticky lg:top-28">
            {/* Coupon Box */}
            <div className="p-5 rounded-2xl bg-white border border-[#281A1D]/10 space-y-3">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#281A1D]">
                <Tag className="w-4 h-4 text-[#701C35]" />
                <span>Apply Coupon Code</span>
              </div>

              <form onSubmit={handleCouponSubmit} className="flex gap-2">
                <input
                  type="text"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                  placeholder="Enter code (e.g. GRACE10)"
                  aria-label="Coupon code"
                  className="flex-1 px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-xs uppercase font-semibold focus:outline-none focus:border-[#701C35]"
                />
                <button
                  type="submit"
                  className="px-4 py-2.5 rounded-lg bg-[#701C35] hover:bg-[#3D101D] text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Apply
                </button>
              </form>

              {couponMsg && (
                <p
                  className={`text-xs font-medium ${
                    couponMsg.valid ? 'text-[#701C35]' : 'text-red-700'
                  }`}
                >
                  {couponMsg.text}
                </p>
              )}

              <div className="pt-2 space-y-1.5">
                <p className="text-[11px] font-medium text-[#77706D]">
                  Available Patron Coupons:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {Object.values(VALID_COUPONS).map((c) => (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => {
                        setCouponInput(c.code);
                        const res = validateCouponCode(c.code, summary.subtotal);
                        setCouponMsg({ valid: res.valid, text: res.message });
                        if (res.valid) onApplyCoupon(c.code);
                      }}
                      className="text-[11px] px-2.5 py-1 rounded-md bg-[#FAF5F0] hover:bg-[#E8C5CA]/50 border border-[#701C35]/25 text-[#701C35] font-semibold cursor-pointer"
                    >
                      {c.code}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Order Summary Breakdown */}
            <div className="p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-4">
              <h2 className="font-serif-display text-xl font-semibold text-[#281A1D]">
                Order Summary
              </h2>

              <div className="space-y-2.5 text-sm">
                <div className="flex justify-between text-[#77706D]">
                  <span>Total MRP</span>
                  <span className="tabular-nums">
                    {formatINR(summary.mrpTotal)}
                  </span>
                </div>
                <div className="flex justify-between text-[#701C35]">
                  <span>Discount on MRP</span>
                  <span className="tabular-nums">
                    −{formatINR(summary.productDiscount)}
                  </span>
                </div>
                <div className="flex justify-between text-[#281A1D] font-medium">
                  <span>Subtotal</span>
                  <span className="tabular-nums">
                    {formatINR(summary.subtotal)}
                  </span>
                </div>
                {summary.couponDiscount > 0 && (
                  <div className="flex justify-between text-[#701C35] font-medium">
                    <span>Coupon Discount ({summary.couponCode})</span>
                    <span className="tabular-nums">
                      −{formatINR(summary.couponDiscount)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-[#77706D]">
                  <span>Shipping Charges</span>
                  <span className="tabular-nums">
                    {summary.shippingFee === 0 ? (
                      <span className="text-[#701C35] font-semibold">FREE</span>
                    ) : (
                      formatINR(summary.shippingFee)
                    )}
                  </span>
                </div>

                <div className="pt-3 border-t border-[#281A1D]/10 flex justify-between text-lg font-bold text-[#281A1D]">
                  <span>Final Payable</span>
                  <span
                    data-testid="cart-payable-amount"
                    className="tabular-nums text-[#701C35]"
                  >
                    {formatINR(summary.payableAmount)}
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => onNavigate('checkout')}
                className="w-full py-3.5 px-6 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-sm transition-colors cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

/* ============================================================================
   CHECKOUT PAGE & ORDER CONFIRMATION PAGE
   ============================================================================ */
interface CheckoutViewProps {
  items: CartItem[];
  summary: CartSummary;
  onPlaceOrder: (customer: CheckoutInput) => void;
  onBackToCart: () => void;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({
  items,
  summary,
  onPlaceOrder,
  onBackToCart,
}) => {
  const [form, setForm] = useState<CheckoutInput>({
    fullName: '',
    email: '',
    phone: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: 'Maharashtra',
    pincode: '',
    paymentMethod: 'upi',
    upiId: 'patron@okicici',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateCheckoutForm(form);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }
    setErrors({});
    onPlaceOrder(form);
  };

  return (
    <div className="max-w-[1360px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35]">
            100% Secure Checkout
          </p>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
            Shipping &amp; Payment
          </h1>
        </div>
        <button
          type="button"
          onClick={onBackToCart}
          className="text-xs sm:text-sm font-medium text-[#701C35] hover:underline cursor-pointer"
        >
          ← Return to Bag
        </button>
      </div>

      <form
        onSubmit={handleSubmit}
        noValidate
        className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
      >
        {/* Left: Customer & Address Details + Payment Method */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-4">
            <h2 className="font-serif-display text-xl font-semibold text-[#281A1D]">
              1. Customer &amp; Delivery Address
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label
                  htmlFor="checkout-name"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  Full Name *
                </label>
                <input
                  id="checkout-name"
                  type="text"
                  value={form.fullName}
                  onChange={(e) =>
                    setForm({ ...form, fullName: e.target.value })
                  }
                  placeholder="Ananya Sharma"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35]"
                />
                {errors.fullName && (
                  <p className="text-xs text-red-700 mt-1">{errors.fullName}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="checkout-phone"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  Mobile Number (10 digits) *
                </label>
                <input
                  id="checkout-phone"
                  type="tel"
                  maxLength={10}
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="9876543210"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35] tabular-nums"
                />
                {errors.phone && (
                  <p className="text-xs text-red-700 mt-1">{errors.phone}</p>
                )}
              </div>
            </div>

            <div>
              <label
                htmlFor="checkout-email"
                className="block text-xs font-semibold text-[#281A1D] mb-1"
              >
                Email Address *
              </label>
              <input
                id="checkout-email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="ananya.sharma@example.com"
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35]"
              />
              {errors.email && (
                <p className="text-xs text-red-700 mt-1">{errors.email}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="checkout-address1"
                className="block text-xs font-semibold text-[#281A1D] mb-1"
              >
                House / Flat No., Building &amp; Street Address *
              </label>
              <input
                id="checkout-address1"
                type="text"
                value={form.addressLine1}
                onChange={(e) =>
                  setForm({ ...form, addressLine1: e.target.value })
                }
                placeholder="42 Royal Heritage Apartments, Linking Road"
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35]"
              />
              {errors.addressLine1 && (
                <p className="text-xs text-red-700 mt-1">
                  {errors.addressLine1}
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label
                  htmlFor="checkout-pincode"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  Pincode *
                </label>
                <input
                  id="checkout-pincode"
                  type="text"
                  maxLength={6}
                  value={form.pincode}
                  onChange={(e) =>
                    setForm({ ...form, pincode: e.target.value })
                  }
                  placeholder="400001"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35] tabular-nums"
                />
                {errors.pincode && (
                  <p className="text-xs text-red-700 mt-1">{errors.pincode}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="checkout-city"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  City *
                </label>
                <input
                  id="checkout-city"
                  type="text"
                  value={form.city}
                  onChange={(e) => setForm({ ...form, city: e.target.value })}
                  placeholder="Mumbai"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35]"
                />
                {errors.city && (
                  <p className="text-xs text-red-700 mt-1">{errors.city}</p>
                )}
              </div>

              <div>
                <label
                  htmlFor="checkout-state"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  State *
                </label>
                <select
                  id="checkout-state"
                  value={form.state}
                  onChange={(e) => setForm({ ...form, state: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm bg-white focus:outline-none focus:border-[#701C35]"
                >
                  {[
                    'Maharashtra',
                    'Delhi NCR',
                    'Karnataka',
                    'Rajasthan',
                    'Gujarat',
                    'Tamil Nadu',
                    'Telangana',
                    'Uttar Pradesh',
                    'West Bengal',
                    'Punjab',
                  ].map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Payment Method Selection */}
          <div className="p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-4">
            <h2 className="font-serif-display text-xl font-semibold text-[#281A1D]">
              2. Select Payment Method
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                {
                  id: 'upi',
                  title: 'UPI (GPay, PhonePe, Paytm)',
                  sub: 'Instant zero-fee payment',
                  icon: Smartphone,
                },
                {
                  id: 'card',
                  title: 'Credit / Debit Card',
                  sub: 'Visa, Mastercard, RuPay, Amex',
                  icon: CreditCard,
                },
                {
                  id: 'netbanking',
                  title: 'NetBanking',
                  sub: 'All major Indian banks supported',
                  icon: Building2,
                },
                {
                  id: 'cod',
                  title: 'Cash on Delivery (COD)',
                  sub: 'Pay via cash or UPI at doorstep',
                  icon: Banknote,
                },
              ].map((pm) => {
                const Icon = pm.icon;
                const active = form.paymentMethod === pm.id;
                return (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() =>
                      setForm({ ...form, paymentMethod: pm.id as any })
                    }
                    className={`flex items-start gap-3 p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                      active
                        ? 'border-[#701C35] bg-[#FAF5F0] ring-1 ring-[#701C35]'
                        : 'border-[#281A1D]/15 bg-white hover:border-[#701C35]/50'
                    }`}
                  >
                    <Icon className="w-5 h-5 text-[#701C35] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-[#281A1D]">
                        {pm.title}
                      </p>
                      <p className="text-[11px] text-[#77706D]">{pm.sub}</p>
                    </div>
                  </button>
                );
              })}
            </div>

            {form.paymentMethod === 'upi' && (
              <div className="pt-2">
                <label
                  htmlFor="checkout-upi"
                  className="block text-xs font-semibold text-[#281A1D] mb-1"
                >
                  Enter UPI ID *
                </label>
                <input
                  id="checkout-upi"
                  type="text"
                  value={form.upiId}
                  onChange={(e) => setForm({ ...form, upiId: e.target.value })}
                  placeholder="yourname@okicici"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-[#281A1D]/20 text-sm focus:outline-none focus:border-[#701C35]"
                />
                {errors.upiId && (
                  <p className="text-xs text-red-700 mt-1">{errors.upiId}</p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right: Order Summary & Submit */}
        <div className="lg:col-span-5 p-6 rounded-2xl bg-white border border-[#281A1D]/10 space-y-5 lg:sticky lg:top-28">
          <h2 className="font-serif-display text-xl font-semibold text-[#281A1D]">
            Order Summary ({summary.itemCount} Items)
          </h2>

          <div className="max-h-60 overflow-y-auto space-y-3 pr-1">
            {items.map((item) => (
              <div
                key={`${item.product.id}-${item.size}-${item.color}`}
                className="flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    referrerPolicy="no-referrer"
                    className="w-11 h-14 object-cover object-top rounded-md bg-[#F2E8DF] shrink-0"
                  />
                  <div className="min-w-0">
                    <p className="font-medium text-[#281A1D] truncate">
                      {item.product.name}
                    </p>
                    <p className="text-[#77706D]">
                      Qty: {item.quantity} · Size: {item.size}
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-[#281A1D] tabular-nums shrink-0">
                  {formatINR(item.product.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>

          <div className="space-y-2 text-sm pt-3 border-t border-[#281A1D]/10">
            <div className="flex justify-between text-[#77706D]">
              <span>Subtotal</span>
              <span className="tabular-nums">{formatINR(summary.subtotal)}</span>
            </div>
            {summary.couponDiscount > 0 && (
              <div className="flex justify-between text-[#701C35]">
                <span>Coupon ({summary.couponCode})</span>
                <span className="tabular-nums">
                  −{formatINR(summary.couponDiscount)}
                </span>
              </div>
            )}
            <div className="flex justify-between text-[#77706D]">
              <span>Shipping</span>
              <span className="tabular-nums">
                {summary.shippingFee === 0
                  ? 'FREE'
                  : formatINR(summary.shippingFee)}
              </span>
            </div>
            <div className="flex justify-between text-lg font-bold text-[#281A1D] pt-2 border-t border-[#281A1D]/10">
              <span>Total Payable</span>
              <span className="tabular-nums text-[#701C35]">
                {formatINR(summary.payableAmount)}
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 px-6 rounded-xl bg-[#701C35] hover:bg-[#3D101D] text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md transition-colors cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Place Order — {formatINR(summary.payableAmount)}</span>
          </button>
        </div>
      </form>
    </div>
  );
};

/* ============================================================================
   ORDER CONFIRMATION VIEW
   ============================================================================ */
interface OrderConfirmationViewProps {
  order: OrderRecord;
  onContinueShopping: () => void;
}

export const OrderConfirmationView: React.FC<OrderConfirmationViewProps> = ({
  order,
  onContinueShopping,
}) => {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="bg-white rounded-3xl border border-[#281A1D]/10 p-6 sm:p-10 shadow-sm space-y-6 text-center">
        <div className="w-16 h-16 rounded-full bg-[#701C35]/10 text-[#701C35] flex items-center justify-center mx-auto">
          <CheckCircle2 className="w-9 h-9" />
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-widest text-[#701C35]">
            Thank You For Shopping With Urban by Grace
          </p>
          <h1 className="font-serif-display text-3xl sm:text-4xl font-semibold text-[#281A1D]">
            Order #{order.orderId} Confirmed
          </h1>
          <p className="text-sm text-[#77706D]">
            A confirmation receipt has been sent to{' '}
            <strong className="text-[#281A1D]">{order.customer.email}</strong>.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left p-4 rounded-2xl bg-[#FAF5F0] border border-[#281A1D]/10 text-xs">
          <div>
            <p className="text-[#77706D] uppercase font-semibold">Delivering To</p>
            <p className="font-semibold text-[#281A1D] mt-1">
              {order.customer.fullName}
            </p>
            <p className="text-[#77706D]">
              {order.customer.addressLine1}, {order.customer.city} —{' '}
              {order.customer.pincode}
            </p>
          </div>
          <div>
            <p className="text-[#77706D] uppercase font-semibold">
              Estimated Delivery
            </p>
            <p className="font-semibold text-[#701C35] mt-1">
              {order.estimatedDelivery}
            </p>
            <p className="text-[#77706D]">Status: {order.status}</p>
          </div>
          <div>
            <p className="text-[#77706D] uppercase font-semibold">
              Payment Summary
            </p>
            <p className="font-bold text-sm text-[#281A1D] mt-1 tabular-nums">
              {formatINR(order.summary.payableAmount)}
            </p>
            <p className="text-[#77706D] uppercase">
              Method: {order.customer.paymentMethod}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onContinueShopping}
          className="inline-flex items-center gap-2 bg-[#701C35] hover:bg-[#3D101D] text-white text-sm font-semibold px-8 py-3.5 rounded-full transition-colors cursor-pointer"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
