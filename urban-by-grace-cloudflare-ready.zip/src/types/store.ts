export type PageId =
  | 'home'
  | 'women'
  | 'men'
  | 'new-arrivals'
  | 'ethnic-wear'
  | 'western-wear'
  | 'dresses'
  | 'kurtas-suits'
  | 'tops-tees'
  | 'coord-sets'
  | 'bags-accessories'
  | 'sale'
  | 'product-details'
  | 'wishlist'
  | 'cart'
  | 'checkout'
  | 'order-confirmation'
  | 'account'
  | 'about'
  | 'contact'
  | 'privacy-policy'
  | 'shipping-policy'
  | 'return-policy';

export type SizeOption = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface ColorVariant {
  name: string;
  hex: string;
}

export interface ProductReview {
  id: string;
  author: string;
  location: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verifiedSize: SizeOption;
}

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  price: number;
  originalPrice: number;
  discountPercent: number;
  category:
    | 'kurtas-suits'
    | 'dresses'
    | 'tops-tees'
    | 'coord-sets'
    | 'ethnic-wear'
    | 'mens-wear'
    | 'bags-accessories';
  gender: 'women' | 'men' | 'unisex';
  collection: 'ethnic' | 'western' | 'accessories';
  isNewArrival?: boolean;
  isOnSale?: boolean;
  isBestseller?: boolean;
  images: string[];
  imagePosition?: string;
  imageScale?: string;
  sizes: SizeOption[];
  colors: ColorVariant[];
  description: string;
  fabricDetails: string[];
  careInstructions: string;
  fitNotes: string;
  rating: number;
  reviewCount: number;
  reviews: ProductReview[];
  sku: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  pageId: PageId;
  image: string;
  itemCount: string;
  imagePosition?: string;
}

export interface CartItem {
  product: Product;
  size: SizeOption;
  color: string;
  quantity: number;
}

export interface CartSummary {
  itemCount: number;
  mrpTotal: number;
  productDiscount: number;
  subtotal: number;
  couponCode: string | null;
  couponDiscount: number;
  shippingFee: number;
  freeShippingRemaining: number;
  payableAmount: number;
}

export interface PincodeCheckResult {
  valid: boolean;
  pincode: string;
  city?: string;
  state?: string;
  estimatedDays?: string;
  deliveryDateLabel?: string;
  codAvailable?: boolean;
  expressAvailable?: boolean;
  error?: string;
}

export interface CheckoutInput {
  fullName: string;
  email: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  pincode: string;
  paymentMethod: 'upi' | 'card' | 'netbanking' | 'cod';
  upiId?: string;
}

export interface OrderRecord {
  orderId: string;
  placedAt: string;
  items: CartItem[];
  summary: CartSummary;
  customer: CheckoutInput;
  estimatedDelivery: string;
  status: 'Confirmed' | 'Packed' | 'In Transit' | 'Delivered';
}

export interface FilterOptions {
  pageId?: PageId;
  searchQuery?: string;
  selectedCategory?: string;
  selectedSize?: SizeOption | 'ALL';
  priceRange?: 'all' | 'under-1500' | '1500-2500' | 'above-2500';
  sortBy?: 'featured' | 'price-asc' | 'price-desc' | 'discount' | 'rating';
}
